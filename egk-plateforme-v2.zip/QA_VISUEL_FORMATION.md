# Validation visuelle — visuel étudiants GK Formation

Date de contrôle : 23 août 2026.

La page publique `/formation` a été vérifiée en rendu desktop pleine page (viewport 1280 × 720). Le visuel référencé est `/manus-storage/gk-formation-etudiants-alpha_4d6bcc1a.png`.

Le contrôle visuel confirme que **le damier précédemment visible a disparu** : seuls les étudiants sont visibles sur la teinte bleu très clair de leur section, sans trame ni fond quadrillé. Le conteneur `.training-programs__students` est explicitement défini avec `background: transparent` et l’image ne reçoit qu’une ombre portée douce pour son intégration.

La rubrique Formation conserve ainsi le groupe d’étudiants détouré, les filières officielles et l’appel à l’inscription sans réintroduire l’affiche complète.
