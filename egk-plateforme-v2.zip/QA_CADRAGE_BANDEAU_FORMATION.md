# Validation visuelle — bandeau Formation & institut

Date de contrôle : 24 août 2026.

Le bandeau supérieur de la page publique `/formation` a été vérifié après agrandissement du visuel des étudiants, sur les deux formats suivants :

| Format contrôlé | Résultat du cadrage |
|---|---|
| Desktop — 1280 × 720 | Les trois étudiants sont visibles du haut du corps jusqu’aux jambes, avec les pieds hors du bandeau. Le titre et le bouton restent dégagés à gauche. |
| Mobile — 375 × 812 | Le cadrage privilégie les visages et le buste ; les pieds ne sont plus visibles. Le texte, le bouton et le menu restent lisibles. |

Le visuel est traité en arrière-plan non interactif. Son agrandissement et son ancrage par le haut préservent la lisibilité du premier bandeau bleu « Formation & institut ».
