import { ArrowUpRight, Mail } from "lucide-react";
import React from "react";
import { getPropertyOwnerEmailHref } from "@shared/propertyListingContact";

type PropertyOwnerContactPanelProps = {
  title: string;
  whatsappHref?: string;
  ownerEmail?: string;
};

export function PropertyOwnerContactPanel({ title, whatsappHref, ownerEmail }: PropertyOwnerContactPanelProps) {
  function submitEmail(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!ownerEmail) return;
    const form = new FormData(event.currentTarget);
    window.location.href = getPropertyOwnerEmailHref(ownerEmail, title, String(form.get("senderName") ?? ""), String(form.get("message") ?? ""));
  }

  if (!whatsappHref && !ownerEmail) return null;

  return <div className="owner-contact-panel">
    {whatsappHref && <a className="button button--gold property-contact-button" href={whatsappHref} target="_blank" rel="noreferrer">Contacter par WhatsApp <ArrowUpRight size={17} /></a>}
    {ownerEmail && <form className="owner-email-form" onSubmit={submitEmail}><div><span className="eyebrow eyebrow--gold">E-mail direct</span><h3>Écrire au propriétaire</h3></div><label>Votre nom<input name="senderName" required placeholder="Votre nom complet" /></label><label>Votre message<textarea name="message" required rows={4} placeholder="Indiquez votre demande ou votre souhait de visite." /></label><button type="submit" className="button button--gold"><Mail size={17} />Préparer l’e-mail</button></form>}
  </div>;
}
