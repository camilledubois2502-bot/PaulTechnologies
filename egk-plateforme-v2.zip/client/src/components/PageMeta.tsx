import { useEffect } from "react";
import { siteName } from "@/lib/siteData";

export default function PageMeta({ title, description }: { title: string; description: string }) {
  useEffect(() => {
    document.title = `${title} | ${siteName}`;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", description);
  }, [description, title]);
  return null;
}
