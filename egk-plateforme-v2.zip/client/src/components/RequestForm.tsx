import { useEffect, useMemo, useRef, useState } from "react";
import { CheckCircle2, FileImage, Loader2, Paperclip, Video, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { propertyListingFields, requestExtraFields, trainingProgrammes, type RequestExtraField, type RequestType } from "@/lib/siteData";
import { TRAINING_EDUCATION_LEVELS } from "@shared/trainingContact";
import { requestSubmissionFeedback } from "@shared/requestSubmissionFeedback";
import { PROPERTY_MEDIA_MAX_BYTES, PROPERTY_MEDIA_MAX_FILES, PROPERTY_MEDIA_MIN_FILES, getPropertyMediaKind, isPropertyMediaMimeType } from "@shared/propertyMedia";

type RequestFormProps = {
  requestType: RequestType;
  serviceSlug: string;
  title?: string;
  intro?: string;
  compact?: boolean;
  defaultSubject?: string;
  trainingEnrollment?: boolean;
  extraFieldsOverride?: RequestExtraField[];
  propertyOwnerMode?: boolean;
};

type ListingMediaItem = { file: File; previewUrl: string; kind: "image" | "video"; remoteUrl?: string };

export default function RequestForm({ requestType, serviceSlug, title = "Faisons le point sur votre besoin", intro = "L’équipe EGK pourra étudier votre demande et vous recontacter.", compact = false, defaultSubject = "", trainingEnrollment = false, extraFieldsOverride, propertyOwnerMode = false }: RequestFormProps) {
  const createRequest = trpc.serviceRequests.create.useMutation();
  const createPropertyListing = trpc.propertyListings.create.useMutation();
  const extraFields = useMemo(() => extraFieldsOverride ?? requestExtraFields[requestType], [extraFieldsOverride, requestType]);
  const enrollmentFields = useMemo(() => trainingEnrollment ? ["filiere", "niveauEtude"] : [], [trainingEnrollment]);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const [mediaError, setMediaError] = useState("");
  const [listingMedia, setListingMedia] = useState<ListingMediaItem[]>([]);
  const [isUploadingMedia, setIsUploadingMedia] = useState(false);
  const [propertyListingType, setPropertyListingType] = useState("location");
  const successRef = useRef<HTMLDivElement>(null);
  const isPropertyListing = extraFieldsOverride === propertyListingFields;
  const isRentalSearch = requestType === "rental" && (serviceSlug === "location-maisons" || serviceSlug === "rental");
  const feedback = isPropertyListing ? {
    ...requestSubmissionFeedback,
    successEyebrow: propertyOwnerMode ? "Annonce envoyée pour validation" : "Annonce reçue",
    successTitle: propertyOwnerMode ? "Votre annonce est en attente d’approbation." : "Votre annonce a bien été reçue.",
    successMessage: propertyOwnerMode ? "L’équipe E.G.K SARL va vérifier les informations avant de rendre le bien visible dans Immobilier & BTP." : "L’équipe E.G.K SARL va examiner les informations transmises.",
    successNextStep: propertyOwnerMode ? "Vous pourrez retrouver votre compte propriétaire pour déposer d’autres annonces." : "L’administrateur EGK a été averti pour assurer le suivi.",
    restartLabel: "Déposer une autre annonce",
  } : requestSubmissionFeedback;

  useEffect(() => {
    if (submitted) successRef.current?.focus();
  }, [submitted]);

  useEffect(() => () => listingMedia.forEach(media => URL.revokeObjectURL(media.previewUrl)), [listingMedia]);

  function selectListingMedia(event: React.ChangeEvent<HTMLInputElement>) {
    const selected = Array.from(event.target.files ?? []);
    setMediaError("");
    if (!selected.length) return;
    if (listingMedia.length + selected.length > PROPERTY_MEDIA_MAX_FILES) {
      setMediaError(`Vous pouvez ajouter jusqu’à ${PROPERTY_MEDIA_MAX_FILES} médias par annonce.`);
      event.currentTarget.value = "";
      return;
    }
    const invalid = selected.find(file => !isPropertyMediaMimeType(file.type) || file.size > PROPERTY_MEDIA_MAX_BYTES);
    if (invalid) {
      setMediaError("Choisissez uniquement des photos ou vidéos de 15 Mo maximum par fichier.");
      event.currentTarget.value = "";
      return;
    }
    setListingMedia(current => [...current, ...selected.map(file => ({ file, previewUrl: URL.createObjectURL(file), kind: getPropertyMediaKind(file.type) }))]);
    event.currentTarget.value = "";
  }

  function removeListingMedia(previewUrl: string) {
    setListingMedia(current => {
      const selected = current.find(media => media.previewUrl === previewUrl);
      if (selected) URL.revokeObjectURL(selected.previewUrl);
      return current.filter(media => media.previewUrl !== previewUrl);
    });
  }

  async function uploadListingMedia() {
    if (!listingMedia.length) return [] as { url: string; type: "image" | "video"; name: string }[];
    setIsUploadingMedia(true);
    try {
      const uploaded = await Promise.all(listingMedia.map(async media => {
        if (media.remoteUrl) return { url: media.remoteUrl, type: media.kind, name: media.file.name };
        const response = await fetch("/api/property-media-upload", { method: "POST", headers: { "Content-Type": media.file.type, "x-file-name": media.file.name, "x-file-type": media.file.type }, body: media.file });
        const payload = await response.json() as { url?: string; error?: string };
        if (!response.ok || !payload.url) throw new Error(payload.error || "Le média n’a pas pu être importé.");
        return { url: payload.url, type: media.kind, name: media.file.name };
      }));
      setListingMedia(current => current.map((media, index) => ({ ...media, remoteUrl: uploaded[index]?.url })));
      return uploaded;
    } finally {
      setIsUploadingMedia(false);
    }
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const details = Object.fromEntries([...extraFields.map(field => field.name), ...enrollmentFields].map(name => [name, String(form.get(name) ?? "")]).filter(([, value]) => value));
    if (isPropertyListing) {
      details.contactDirectEnabled = form.get("contactDirectEnabled") === "on" ? "true" : "false";
      details.contactEmailEnabled = form.get("contactEmailEnabled") === "on" ? "true" : "false";
      details.availabilityStatus = String(form.get("availabilityStatus") ?? "available");
    }
    setError("");
    setMediaError("");
    try {
      if (isPropertyListing) {
        if (listingMedia.length < PROPERTY_MEDIA_MIN_FILES) {
          setMediaError(`Ajoutez au moins ${PROPERTY_MEDIA_MIN_FILES} médias (photos ou vidéos) avant d’envoyer l’annonce.`);
          return;
        }
        const uploadedMedia = await uploadListingMedia();
        if (uploadedMedia.length) details.mediaGallery = JSON.stringify(uploadedMedia);
      }
      const firstName = String(form.get("firstName") ?? "").trim();
      const lastName = String(form.get("lastName") ?? "").trim();
      const fullName = isRentalSearch ? [lastName, firstName].filter(Boolean).join(" ") : String(form.get("fullName") ?? "");
      const rentalLocation = isRentalSearch ? [String(form.get("villeRecherche") ?? "").trim(), String(form.get("regionRecherche") ?? "").trim()].filter(Boolean).join(" · ") : String(form.get("location") ?? "");
      const payload = {
        requestType,
        serviceSlug,
        fullName,
        phone: String(form.get("phone") ?? ""),
        email: String(form.get("email") ?? ""),
        location: rentalLocation,
        subject: String(form.get("subject") ?? ""),
        message: String(form.get("message") ?? ""),
        details,
      } as const;
      if (propertyOwnerMode) await createPropertyListing.mutateAsync(payload);
      else await createRequest.mutateAsync(payload);
      setSubmitted(true);
      event.currentTarget.reset();
    } catch (mutationError) {
      setError(mutationError instanceof Error ? mutationError.message : "La demande n’a pas pu être envoyée. Veuillez réessayer.");
    }
  }

  if (submitted) {
    return <div ref={successRef} className="form-success" role="status" aria-live="polite" tabIndex={-1}><div className="form-success__icon"><CheckCircle2 size={31} aria-hidden="true" /></div><div><span className="form-success__eyebrow">{feedback.successEyebrow}</span><strong>{feedback.successTitle}</strong><p>{feedback.successMessage}</p><p className="form-success__next">{feedback.successNextStep}</p><button type="button" className="text-link" onClick={() => setSubmitted(false)}>{feedback.restartLabel}</button></div></div>;
  }

  return (
    <section className={`request-form ${compact ? "request-form--compact" : ""}`}>
      <div className="request-form__intro"><span className="eyebrow eyebrow--gold">Demande en ligne</span><h2>{title}</h2><p>{intro}</p><div className="request-form__privacy">Vos informations sont destinées à l’étude de votre demande par EGK.</div></div>
      <form onSubmit={handleSubmit} noValidate>
        <div className="form-grid">
          {isRentalSearch ? <><label>Nom<input name="lastName" required autoComplete="family-name" placeholder="Votre nom" /></label><label>Prénom<input name="firstName" required autoComplete="given-name" placeholder="Votre prénom" /></label></> : <label>Nom et prénom<input name="fullName" required autoComplete="name" placeholder="Votre nom complet" /></label>}
          <label>{isPropertyListing ? "Téléphone WhatsApp du propriétaire" : "Téléphone"}<input name="phone" required inputMode="tel" autoComplete="tel" placeholder={isPropertyListing ? "Numéro WhatsApp joignable" : "Votre numéro joignable"} /></label>
          <label>Email {!isPropertyListing && <span className="optional">facultatif</span>}<input name="email" type="email" autoComplete="email" required={isPropertyListing} placeholder={isPropertyListing ? "E-mail du propriétaire" : "vous@exemple.ci"} /></label>
          {!isRentalSearch && <label>Localisation <span className="optional">facultatif</span><input name="location" autoComplete="address-level2" placeholder="Ville, quartier ou village" /></label>}
          {requestType === "contact" && <label className="form-grid__full">Objet<input name="subject" required defaultValue={defaultSubject} placeholder="Objet de votre message" /></label>}
          {trainingEnrollment && <><label>Filière de formation<select name="filiere" required defaultValue=""><option value="" disabled>Choisissez une filière</option>{trainingProgrammes.map(programme => <option key={programme} value={programme}>{programme}</option>)}</select></label><label>Niveau d’étude actuel<select name="niveauEtude" required defaultValue=""><option value="" disabled>Choisissez votre niveau</option>{TRAINING_EDUCATION_LEVELS.map(level => <option key={level} value={level}>{level}</option>)}</select></label></>}
          {extraFields.map(field => {
            if (isPropertyListing && field.name === "statut") return <label key={field.name}>Type d’annonce<select name="statut" value={propertyListingType} onChange={event => setPropertyListingType(event.target.value)} required><option value="location">Location</option><option value="vente">Vente</option><option value="autre">Autre</option></select></label>;
            const isMonthlyRent = isPropertyListing && field.name === "loyerMensuel";
            return <label key={field.name}>{isMonthlyRent && propertyListingType === "location" ? "Loyer mensuel" : field.label}{(field.required === false && !isMonthlyRent) && <span className="optional">facultatif</span>}{isMonthlyRent && propertyListingType === "location" && <span className="optional">obligatoire pour une location</span>}<input name={field.name} type={field.type ?? "text"} required={isMonthlyRent ? propertyListingType === "location" : field.required ?? (field.name !== "budget" && field.name !== "apport")} placeholder={field.placeholder} /></label>;
          })}
          {isPropertyListing && <label>Disponibilité du bien<select name="availabilityStatus" required defaultValue="available"><option value="available">Disponible</option><option value="rented">Loué</option><option value="sold">Vendu</option></select></label>}
          <label className="form-grid__full">Décrivez votre besoin<textarea name="message" required rows={compact ? 4 : 5} placeholder="Donnez les informations utiles pour mieux comprendre votre demande." /></label>
          {isPropertyListing && <label className="form-grid__full listing-contact-consent"><input name="contactDirectEnabled" type="checkbox" required /> <span>J’autorise E.G.K SARL à afficher un bouton de contact WhatsApp destiné à ce numéro après approbation de l’annonce.</span></label>}
          {isPropertyListing && <label className="form-grid__full listing-contact-consent"><input name="contactEmailEnabled" type="checkbox" required /> <span>J’autorise E.G.K SARL à afficher un formulaire de contact e-mail destiné à cette adresse après approbation de l’annonce.</span></label>}
        </div>
        {isPropertyListing && <div className="listing-media-uploader"><div><span className="eyebrow eyebrow--gold">Galerie du bien</span><h3>Ajoutez vos médias obligatoires</h3><p><strong>{PROPERTY_MEDIA_MIN_FILES} médias minimum</strong> et {PROPERTY_MEDIA_MAX_FILES} maximum, photos ou vidéos de 15 Mo maximum par fichier. Ils seront associés à votre annonce après approbation.</p></div><label className="listing-media-uploader__picker"><FileImage size={18} /><span>Sélectionner des médias</span><input type="file" accept="image/*,video/*" multiple onChange={selectListingMedia} /></label>{listingMedia.length > 0 && <div className="listing-media-uploader__preview" aria-label="Aperçu des médias sélectionnés">{listingMedia.map(media => <figure key={media.previewUrl}>{media.kind === "image" ? <img src={media.previewUrl} alt={`Aperçu de ${media.file.name}`} /> : <video src={media.previewUrl} muted playsInline controls aria-label={`Vidéo ${media.file.name}`} />}<figcaption>{media.kind === "video" ? <Video size={14} /> : <FileImage size={14} />}{media.file.name}</figcaption><button type="button" onClick={() => removeListingMedia(media.previewUrl)} aria-label={`Retirer ${media.file.name}`}><X size={15} /></button></figure>)}</div>}</div>}
        {(requestType === "teacher_application" || requestType === "btp_partner" || requestType === "training" || requestType === "construction" || isPropertyListing) && <div className="attachment-notice"><Paperclip size={17} /><span>{isPropertyListing ? "Les médias sélectionnés seront importés avec votre annonce et affichés dans sa galerie après approbation." : "Pièces jointes : l’espace de dépôt sécurisé est prévu dans le module d’administration ; vous pourrez être invité à transmettre les documents requis après étude de cette première demande."}</span></div>}
        {mediaError && <p className="form-error" role="alert">{mediaError}</p>}
        {error && <p className="form-error" role="alert">{error}</p>}
        <button className={`button button--gold form-submit ${createRequest.isPending || createPropertyListing.isPending || isUploadingMedia ? "is-loading" : ""}`} disabled={createRequest.isPending || createPropertyListing.isPending || isUploadingMedia} aria-busy={createRequest.isPending || createPropertyListing.isPending || isUploadingMedia} type="submit">{createRequest.isPending || createPropertyListing.isPending || isUploadingMedia ? <><Loader2 className="form-submit__spinner" size={17} aria-hidden="true" /><span>{isUploadingMedia ? "Import des médias en cours…" : isPropertyListing ? "Envoi pour validation…" : requestSubmissionFeedback.loadingLabel}</span></> : isPropertyListing ? propertyOwnerMode ? "Envoyer pour validation" : "Publier mon annonce" : requestSubmissionFeedback.submitLabel}</button>
      </form>
    </section>
  );
}
