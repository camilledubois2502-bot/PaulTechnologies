import { Link, useLocation } from "wouter";
import { Menu, MessageCircle, X } from "lucide-react";
import { useEffect, useState } from "react";
import { ADMINISTRATION_HREF, getWhatsAppHref, getWhatsAppMessage, legalAddress, legalName, navigationItems, rccmNumber, siteName, siteTagline } from "@/lib/siteData";

function Brand() {
  return (
    <div className="brand-mark" aria-label="E.G.K SARL">
      <span className="brand-copy"><strong>{siteName}</strong><small>{siteTagline}</small></span>
    </div>
  );
}

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setMenuOpen(false), [location]);

  return (
    <div className="min-h-screen overflow-x-hidden bg-[var(--sand-50)] text-[var(--ink)]">
      <header className={`site-header ${scrolled ? "site-header--scrolled" : ""}`}>
        <div className="container site-header__inner">
          <Brand />
          <div className="site-header__actions">
            <button type="button" className={`mobile-menu-toggle top-menu-button ${menuOpen ? "top-menu-button--open" : ""}`} aria-label={menuOpen ? "Fermer le menu" : "Afficher les différentes pages"} aria-expanded={menuOpen} onClick={() => setMenuOpen(value => !value)}>{menuOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}<span>{menuOpen ? "Fermer" : "Menu"}</span></button>
          </div>
        </div>
        {menuOpen && (
          <div className="mobile-menu">
            <div className="container">
              <div className="mobile-menu__brand"><Brand /><p>Les différentes pages d’E.G.K SARL sont accessibles depuis ce menu.</p></div>
              <div className="mobile-menu__links">
                {navigationItems.map(item => <Link key={item.href} href={item.href}>{item.label}</Link>)}
                <Link href="/manuels">Manuels scolaires</Link>
                <Link href={ADMINISTRATION_HREF}>Administration</Link>
              </div>
            </div>
          </div>
        )}
      </header>

      <main className="public-page-main">{children}</main>

      <a className="whatsapp-float" href={getWhatsAppHref(location)} target="_blank" rel="noreferrer" aria-label={getWhatsAppMessage(location)}>
        <MessageCircle size={22} /><span>WhatsApp</span>
      </a>

      <footer className="site-footer">
        <div className="container">
          <div className="site-footer__top">
            <div><Brand /><p>Une plateforme institutionnelle et multiservices pour relier les projets, les opportunités et les besoins du territoire.</p><address className="footer-legal"><strong>{legalName}</strong><span>Siège social : {legalAddress}</span><span>RCCM : {rccmNumber}</span></address></div>
            <div><span className="footer-label">Navigation</span><p>Les différentes pages sont accessibles depuis le bouton Menu épinglé en haut de l’écran.</p></div>
            <div><span className="footer-label">Besoin d’un accompagnement ?</span><p>Utilisez le bouton Menu en haut de l’écran pour accéder au formulaire de demande.</p></div>
          </div>
          <div className="site-footer__bottom"><span>© {new Date().getFullYear()} {legalName}. Tous droits réservés.</span><span>Coordonnées et médias officiels à compléter avant publication.</span></div>
        </div>
      </footer>
    </div>
  );
}
