import {
  BarChart3,
  BookOpenCheck,
  CheckCircle2,
  ClipboardList,
  FileText,
  ImagePlus,
  Inbox,
  KeyRound,
  Loader2,
  LockKeyhole,
  LogIn,
  LogOut,
  Mail,
  PackagePlus,
  Plus,
  Search,
  ShieldCheck,
  Users,
} from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import PageMeta from "@/components/PageMeta";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

const staffRoles = ["admin", "content_manager", "training_manager", "real_estate_manager"];
type AdminModule = "content" | "catalog" | "media" | "manual";

type RequestRecord = {
  id: number;
  requestType: string;
  serviceSlug: string;
  fullName: string;
  phone: string;
  email: string | null;
  location: string | null;
  subject: string | null;
  message: string;
  details: unknown;
  status: string;
  createdAt: Date;
};

function entrySubtitle(entry: { sector?: string; category?: string; level?: string | null }) {
  return entry.sector ?? entry.category ?? entry.level ?? "Manuel protégé";
}

function formatRequestType(type: string) {
  return {
    general: "Demande générale",
    contact: "Contact",
    finance: "Finance",
    construction: "Construction",
    rental: "Location",
    training: "Formation",
    teacher_application: "Candidature enseignant",
    btp_partner: "Partenariat BTP",
    reservation: "Réservation",
    sanitation: "Salubrité",
    fad_interest: "Intérêt formation",
  }[type] ?? type;
}

function getDetails(details: unknown) {
  if (!details || typeof details !== "object" || Array.isArray(details)) return [] as Array<[string, string]>;
  return Object.entries(details as Record<string, unknown>)
    .filter(([, value]) => value !== null && value !== undefined && String(value).trim() !== "")
    .map(([key, value]) => [key, String(value)] as [string, string]);
}

function AdminLogin() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const utils = trpc.useUtils();
  const loginMutation = trpc.adminSession.login.useMutation({
    onSuccess: async () => {
      setError("");
      await utils.adminSession.me.invalidate();
    },
    onError: mutationError => setError(mutationError.message),
  });

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    loginMutation.mutate({ login, password });
  }

  return <main className="admin-login-page">
    <PageMeta title="Accès administration" description="Espace privé de réception des demandes E.G.K SARL." />
    <div className="admin-login-card">
      <div className="admin-login-card__mark"><KeyRound size={21} /><span>E.G.K SARL</span></div>
      <span className="eyebrow">Espace privé</span>
      <h1>La boîte de réception<br /><em>E.G.K SARL.</em></h1>
      <p>Connectez-vous pour consulter les demandes envoyées depuis les formulaires du site : services, immobilier, formation, manuels et contact.</p>
      <form onSubmit={submit} className="admin-login-form">
        <label>Identifiant<input value={login} onChange={event => setLogin(event.target.value)} autoComplete="username" required /></label>
        <label>Mot de passe<input type="password" value={password} onChange={event => setPassword(event.target.value)} autoComplete="current-password" required /></label>
        {error && <p className="admin-login-error" role="alert"><LockKeyhole size={16} />{error}</p>}
        <button type="submit" className="button button--gold" disabled={loginMutation.isPending}>{loginMutation.isPending ? <><Loader2 size={16} className="animate-spin" /> Connexion…</> : <><LogIn size={16} /> Ouvrir l’espace admin</>}</button>
      </form>
      <small>Accès réservé à l’équipe autorisée E.G.K SARL.</small>
    </div>
  </main>;
}

function AdminWorkbench() {
  const [module, setModule] = useState<AdminModule>("content");
  const [message, setMessage] = useState("");
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [isUploadingMedia, setIsUploadingMedia] = useState(false);
  const contents = trpc.admin.content.useQuery(undefined, { enabled: module === "content" });
  const catalog = trpc.admin.catalog.useQuery(undefined, { enabled: module === "catalog" });
  const media = trpc.admin.media.useQuery(undefined, { enabled: module === "media" });
  const manuals = trpc.admin.manuals.useQuery(undefined, { enabled: module === "manual" });
  const createContent = trpc.admin.createContent.useMutation();
  const createCatalog = trpc.admin.createCatalogItem.useMutation();
  const createMedia = trpc.admin.createMediaItem.useMutation();
  const createManual = trpc.admin.createManual.useMutation();
  const pending = createContent.isPending || createCatalog.isPending || createMedia.isPending || createManual.isPending;

  async function uploadAdminMedia(file: File) {
    setIsUploadingMedia(true);
    try {
      const response = await fetch("/api/admin-media-upload", {
        method: "POST",
        headers: { "Content-Type": file.type, "x-file-name": file.name, "x-file-type": file.type },
        body: file,
      });
      const payload = await response.json() as { url?: string; error?: string };
      if (!response.ok || !payload.url) throw new Error(payload.error || "L’image n’a pas pu être importée.");
      return payload.url;
    } finally {
      setIsUploadingMedia(false);
    }
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const isPublished = form.get("isPublished") === "on";
    setMessage("");

    try {
      if (module === "content") {
        await createContent.mutateAsync({
          contentType: String(form.get("contentType")),
          sector: String(form.get("sector")),
          slug: String(form.get("slug")),
          title: String(form.get("title")),
          summary: String(form.get("summary") || ""),
          imageUrl: String(form.get("imageUrl") || ""),
          isPublished,
        });
      } else if (module === "catalog") {
        await createCatalog.mutateAsync({
          kind: String(form.get("kind")) as "property" | "agriculture" | "livestock" | "transport" | "manual",
          sector: String(form.get("sector")),
          slug: String(form.get("slug")),
          title: String(form.get("title")),
          description: String(form.get("description") || ""),
          imageUrl: String(form.get("imageUrl") || ""),
          location: String(form.get("location") || ""),
          priceLabel: String(form.get("priceLabel") || ""),
          availabilityLabel: String(form.get("availabilityLabel") || ""),
          isPublished,
        });
      } else if (module === "media") {
        const uploadedUrl = mediaFile ? await uploadAdminMedia(mediaFile) : String(form.get("fileUrl") || "").trim();
        if (!uploadedUrl) throw new Error("Sélectionnez une image ou renseignez une URL de média.");
        await createMedia.mutateAsync({
          category: String(form.get("category")),
          title: String(form.get("title")),
          altText: String(form.get("altText") || ""),
          fileUrl: uploadedUrl,
          mediaType: String(form.get("mediaType")) as "image" | "video" | "document",
          isPublished,
        });
      } else {
        await createManual.mutateAsync({
          slug: String(form.get("slug")),
          title: String(form.get("title")),
          category: String(form.get("category")),
          level: String(form.get("level") || ""),
          description: String(form.get("description") || ""),
          fileKey: String(form.get("fileKey")),
          isPublished,
        });
      }
      event.currentTarget.reset();
      setMediaFile(null);
      setMessage("Entrée enregistrée. Elle apparaît dans la liste de gestion correspondante.");
      await Promise.all([contents.refetch(), catalog.refetch(), media.refetch(), manuals.refetch()]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "L’enregistrement n’a pas abouti.");
    }
  }

  const entries = module === "content" ? contents.data ?? [] : module === "catalog" ? catalog.data ?? [] : module === "media" ? media.data ?? [] : manuals.data ?? [];
  const moduleCopy = {
    content: { label: "Contenu", intro: "Pages, annonces et projets", icon: FileText },
    catalog: { label: "Catalogue", intro: "Maisons, produits, lignes et manuels", icon: PackagePlus },
    media: { label: "Médias", intro: "Images, vidéos et documents référencés", icon: ImagePlus },
    manual: { label: "Manuel", intro: "Bibliothèque sécurisée pour les rôles autorisés", icon: BookOpenCheck },
  }[module];
  const ModuleIcon = moduleCopy.icon;

  return <section className="admin-workbench">
    <div className="admin-panel__heading"><div><span className="eyebrow">Gestion de contenu</span><h2>Publier et organiser</h2></div><span>Entrées administrées via accès sécurisé</span></div>
    <div className="admin-module-tabs">{(["content", "catalog", "media", "manual"] as const).map(item => <button key={item} type="button" className={module === item ? "is-active" : ""} onClick={() => { setModule(item); setMessage(""); }}>
      {item === "content" ? <FileText size={16} /> : item === "catalog" ? <PackagePlus size={16} /> : item === "media" ? <ImagePlus size={16} /> : <BookOpenCheck size={16} />}
      {item === "content" ? "Contenus" : item === "catalog" ? "Catalogue" : item === "media" ? "Médias" : "Manuels"}
    </button>)}</div>
    <div className="admin-workbench__grid">
      <div className="admin-entry-form"><div className="admin-entry-form__title"><ModuleIcon size={19} /><div><strong>Nouvelle entrée {moduleCopy.label.toLowerCase()}</strong><span>{moduleCopy.intro}</span></div></div>
        <form onSubmit={submit}><div className="admin-form-grid">
          {module === "content" && <><label>Type<select name="contentType" defaultValue="page"><option value="page">Page</option><option value="projet">Projet</option><option value="annonce">Annonce</option></select></label><label>Secteur<input name="sector" placeholder="Ex. formation" required /></label></>}
          {module === "catalog" && <><label>Catégorie<select name="kind" defaultValue="property"><option value="property">Immobilier</option><option value="agriculture">Agriculture</option><option value="livestock">Élevage</option><option value="transport">Transport</option><option value="manual">Manuel</option></select></label><label>Secteur<input name="sector" placeholder="Ex. immobilier-btp" required /></label></>}
          {module === "media" && <><label>Catégorie<input name="category" placeholder="Ex. réalisations" required /></label><label>Type de média<select name="mediaType" defaultValue="image"><option value="image">Image</option><option value="video">Vidéo</option><option value="document">Document</option></select></label></>}
          {module === "manual" && <><label>Catégorie<input name="category" placeholder="Ex. Mathématiques" required /></label><label>Niveau<input name="level" placeholder="Ex. 3e" /></label></>}
          <label className="admin-form-full">Titre<input name="title" placeholder="Titre affiché" required /></label>
          {module !== "media" && <label className="admin-form-full">Slug URL<input name="slug" placeholder="exemple-de-titre" required /></label>}
          {module === "catalog" && <><label>Localisation<input name="location" placeholder="Ville ou zone" /></label><label>Disponibilité<input name="availabilityLabel" placeholder="Ex. Disponible" /></label><label>Information tarifaire<input name="priceLabel" placeholder="Ex. Sur demande" /></label></>}
          {module === "content" && <label className="admin-form-full">Résumé<textarea name="summary" rows={3} placeholder="Résumé public de l’entrée" /></label>}
          {module === "catalog" && <label className="admin-form-full">Description<textarea name="description" rows={3} placeholder="Description de la fiche" /></label>}
          {module === "manual" && <><label className="admin-form-full">Clé de stockage du document<input name="fileKey" placeholder="manuels/nom-du-document.pdf ou /manus-storage/…" required /></label><label className="admin-form-full">Description<textarea name="description" rows={3} placeholder="Description du manuel" /></label></>}
          {module === "media" ? <><label className="admin-form-full">Importer une image<input name="mediaFile" type="file" accept="image/*" onChange={event => setMediaFile(event.target.files?.[0] ?? null)} /><small>Import sécurisé dans la galerie E.G.K SARL. Vous pouvez aussi utiliser une URL ci-dessous.</small></label><label className="admin-form-full">URL du média <span>facultatif si une image est importée</span><input name="fileUrl" placeholder="https://… ou /manus-storage/…" /></label><label className="admin-form-full">Texte alternatif<input name="altText" placeholder="Description accessible du média" /></label></> : module !== "manual" && <label className="admin-form-full">URL de l’image <span>facultatif</span><input name="imageUrl" placeholder="https://… ou /manus-storage/…" /></label>}
          <label className="admin-check"><input type="checkbox" name="isPublished" /> <span>Publier immédiatement</span></label>
        </div>{message && <p className="admin-message"><CheckCircle2 size={16} />{message}</p>}<button type="submit" className="button button--dark" disabled={pending || isUploadingMedia}>{isUploadingMedia ? <><Loader2 size={16} className="animate-spin" /> Import de l’image…</> : pending ? <><Loader2 size={16} className="animate-spin" /> Enregistrement</> : <><Plus size={16} /> Enregistrer l’entrée</>}</button></form>
      </div>
      <div className="admin-entry-list"><div><span className="eyebrow">Éléments récents</span><p>{entries.length} entrée{entries.length > 1 ? "s" : ""} enregistrée{entries.length > 1 ? "s" : ""}</p></div><div className="admin-entry-list__items">{entries.length ? entries.map(entry => <article key={entry.id}><div><strong>{entry.title}</strong><span>{entrySubtitle(entry)}</span></div><span className={entry.isPublished ? "status-published" : "status-draft"}>{entry.isPublished ? "Publié" : "Brouillon"}</span></article>) : <div className="admin-entry-list__empty"><FileText size={21} />Aucune entrée dans ce module.</div>}</div></div>
    </div>
  </section>;
}

function InboxPanel({ requests }: { requests: RequestRecord[] }) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const filteredRequests = useMemo(() => {
    const term = search.trim().toLowerCase();
    return requests.filter(request => {
      const matchesStatus = status === "all" || request.status === status;
      const haystack = [request.fullName, request.email, request.phone, request.subject, request.message, request.serviceSlug, request.requestType].filter(Boolean).join(" ").toLowerCase();
      return matchesStatus && (!term || haystack.includes(term));
    });
  }, [requests, search, status]);

  return <section className="admin-panel admin-inbox-panel">
    <div className="admin-panel__heading"><div><span className="eyebrow"><Inbox size={14} /> Réception centralisée</span><h2>Toutes les soumissions</h2></div><span>{requests.length} demande{requests.length > 1 ? "s" : ""} conservée{requests.length > 1 ? "s" : ""}</span></div>
    <div className="admin-inbox-note"><Mail size={18} /><p>Chaque formulaire du site arrive ici : service, immobilier, formation, commande de manuels et contact. Les informations restent accessibles même sans connexion Gmail.</p></div>
    <div className="admin-inbox-toolbar"><label><Search size={16} /><span className="sr-only">Rechercher une soumission</span><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Rechercher un nom, e-mail, service…" /></label><select value={status} onChange={event => setStatus(event.target.value)} aria-label="Filtrer par statut"><option value="all">Tous les statuts</option><option value="new">Nouvelles</option><option value="in_review">En cours</option><option value="contacted">Contactées</option><option value="closed">Clôturées</option></select></div>
    {filteredRequests.length ? <div className="request-table">{filteredRequests.map(request => <article key={request.id} className="request-card"><div className="request-card__identity"><strong>{request.fullName}</strong><span>{request.phone}</span><a href={request.email ? `mailto:${request.email}` : undefined}>{request.email || "E-mail non renseigné"}</a><span>{request.location || "Localisation non renseignée"}</span></div><div className="request-card__message"><span className="request-type-label">{formatRequestType(request.requestType)} · {request.serviceSlug}</span>{request.subject && <strong>{request.subject}</strong>}<p>{request.message}</p>{getDetails(request.details).length > 0 && <dl>{getDetails(request.details).map(([key, value]) => <div key={key}><dt>{key}</dt><dd>{value}</dd></div>)}</dl>}</div><div className="request-card__meta"><span className="request-status">{request.status}</span><small>{new Date(request.createdAt).toLocaleString("fr-FR")}</small></div></article>)}</div> : <div className="admin-empty"><ClipboardList size={26} /><p>{requests.length ? "Aucune soumission ne correspond à votre recherche." : "Aucune demande enregistrée pour le moment."}</p></div>}
  </section>;
}

function AdminWorkspace({ user }: { user: ReturnType<typeof useAuth>["user"] }) {
  const isManusStaff = staffRoles.includes(user?.role ?? "");
  const requestsQuery = trpc.serviceRequests.list.useQuery(undefined, { enabled: true });
  const stats = trpc.admin.stats.useQuery(undefined, { enabled: true });
  const canReviewProperties = !isManusStaff || user?.role === "admin" || user?.role === "real_estate_manager";
  const propertyListings = trpc.propertyListings.listForReview.useQuery(undefined, { enabled: canReviewProperties });
  const reviewPropertyListing = trpc.propertyListings.review.useMutation();
  const utils = trpc.useUtils();
  const logoutMutation = trpc.adminSession.logout.useMutation({
    onSuccess: () => utils.adminSession.me.setData(undefined, { authenticated: false }),
  });

  async function logout() {
    await logoutMutation.mutateAsync();
  }

  async function reviewListing(id: number, status: "published" | "rejected") {
    await reviewPropertyListing.mutateAsync({ id, status });
    await propertyListings.refetch();
  }

  return <main className="admin-shell">
    <header className="admin-shell__header"><div><span className="eyebrow">Administration privée</span><h1>Le centre de pilotage<br /><em>E.G.K SARL.</em></h1><p>Réceptionnez, consultez et traitez tous les messages envoyés depuis la plateforme.</p></div><div className="admin-shell__actions"><span className="admin-role"><ShieldCheck size={17} />{isManusStaff ? "Compte équipe" : "Session administrateur"}</span><button type="button" className="button button--dark button--compact" onClick={logout}><LogOut size={15} /> Fermer la session</button></div></header>
    <section className="admin-kpis"><article><ClipboardList size={20} /><span>Demandes reçues</span><strong>{stats.data?.requests ?? "—"}</strong></article><article><FileText size={20} /><span>Contenus</span><strong>{stats.data?.content ?? "—"}</strong></article><article><PackagePlus size={20} /><span>Catalogues</span><strong>{stats.data?.catalog ?? "—"}</strong></article><article><ImagePlus size={20} /><span>Médias</span><strong>{stats.data?.media ?? "—"}</strong></article></section>
    <InboxPanel requests={(requestsQuery.data ?? []) as RequestRecord[]} />
    {canReviewProperties && <section className="admin-panel"><div className="admin-panel__heading"><div><span className="eyebrow">Immobilier & BTP</span><h2>Validation des annonces</h2></div><span>{propertyListings.isLoading ? "Chargement…" : `${propertyListings.data?.filter(listing => listing.status === "pending").length ?? 0} à examiner`}</span></div>{propertyListings.data?.length ? <div className="property-review-list">{propertyListings.data.map(listing => <article key={listing.id}><div><span>{listing.listingType}</span><strong>{listing.title}</strong><p>{listing.ownerName} · {listing.contactPhone} · {Array.isArray(listing.gallery) ? listing.gallery.length : 0} média(s)</p></div><div><span className={listing.status === "published" ? "status-published" : listing.status === "rejected" ? "status-draft" : "request-status"}>{listing.status === "pending" ? "À valider" : listing.status === "published" ? "Publié" : "Refusé"}</span>{listing.status === "pending" && <div className="property-review-list__actions"><button type="button" className="button button--gold" disabled={reviewPropertyListing.isPending} onClick={() => reviewListing(listing.id, "published")}>Publier</button><button type="button" className="text-link" disabled={reviewPropertyListing.isPending} onClick={() => reviewListing(listing.id, "rejected")}>Refuser</button></div>}</div></article>)}</div> : <div className="admin-empty"><ImagePlus size={26} /><p>Aucune annonce immobilière à examiner.</p></div>}</section>}
    <AdminWorkbench />
    <section className="admin-modules"><article><Users size={22} /><h2>Comptes & rôles</h2><p>Les comptes Manus de l’équipe peuvent continuer à accéder aux outils selon leur rôle.</p></article><article><Mail size={22} /><h2>Réception interne</h2><p>Les demandes sont stockées dans la base de la plateforme, sans dépendre d’une boîte Gmail.</p></article><article><BarChart3 size={22} /><h2>Suivi</h2><p>Les indicateurs de demandes et de contenus restent disponibles depuis cet espace.</p></article></section>
  </main>;
}

export default function AdminPage() {
  const { user } = useAuth();
  const adminSession = trpc.adminSession.me.useQuery(undefined, { retry: false });
  // Même les comptes équipe doivent passer par la page de connexion ADMIN.
  // La session Manus seule ne donne pas accès à cette boîte de réception locale.
  const authenticated = Boolean(adminSession.data?.authenticated);

  if (adminSession.isLoading) return <main className="admin-login-page"><Loader2 className="animate-spin" size={28} /></main>;
  if (!authenticated) return <AdminLogin />;
  return <><PageMeta title="Administration E.G.K SARL" description="Boîte de réception et espace de pilotage E.G.K SARL." /><AdminWorkspace user={user} /></>;
}
