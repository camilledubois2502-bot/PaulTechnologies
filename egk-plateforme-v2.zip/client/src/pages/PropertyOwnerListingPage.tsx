import { Building2, CheckCircle2, KeyRound, LogIn, LogOut, UserPlus } from "lucide-react";
import { FormEvent, useState } from "react";
import PageMeta from "@/components/PageMeta";
import PublicLayout from "@/components/PublicLayout";
import RequestForm from "@/components/RequestForm";
import { trpc } from "@/lib/trpc";
import { PROPERTY_LISTING_SERVICE_SLUG, propertyListingFields } from "@/lib/siteData";

export default function PropertyOwnerListingPage() {
  const owner = trpc.propertyOwner.me.useQuery();
  const utils = trpc.useUtils();
  const [mode, setMode] = useState<"login" | "register">("register");
  const [error, setError] = useState("");
  const login = trpc.propertyOwner.login.useMutation({
    onSuccess: async () => {
      setError("");
      await utils.propertyOwner.me.invalidate();
    },
    onError: mutationError => setError(mutationError.message),
  });
  const register = trpc.propertyOwner.register.useMutation({
    onSuccess: async () => {
      setError("");
      await utils.propertyOwner.me.invalidate();
    },
    onError: mutationError => setError(mutationError.message),
  });
  const logout = trpc.propertyOwner.logout.useMutation({
    onSuccess: async () => utils.propertyOwner.me.invalidate(),
  });

  function submitAccess(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setError("");
    if (mode === "login") {
      login.mutate({ email: String(form.get("email") ?? ""), password: String(form.get("password") ?? "") });
      return;
    }
    const password = String(form.get("password") ?? "");
    const passwordConfirmation = String(form.get("passwordConfirmation") ?? "");
    if (password !== passwordConfirmation) {
      setError("Les deux mots de passe doivent être identiques.");
      return;
    }
    register.mutate({
      fullName: String(form.get("fullName") ?? ""),
      phone: String(form.get("phone") ?? ""),
      email: String(form.get("email") ?? ""),
      password,
    });
  }

  const isAccessPending = login.isPending || register.isPending;

  return <PublicLayout>
    <PageMeta title="Publier une annonce immobilière" description="Inscription et dépôt sécurisé d’une annonce immobilière pour validation par E.G.K SARL." />
    <section className="owner-listing-hero"><div className="container"><span className="eyebrow eyebrow--gold">Propriétaires & mandataires</span><h1>Publier un bien, avec<br /><em>un parcours sécurisé.</em></h1><p>Créez votre compte propriétaire, renseignez votre bien puis envoyez l’annonce à E.G.K SARL. Elle sera visible dans le catalogue immobilier uniquement après approbation de l’administration.</p><div className="owner-listing-steps"><span><strong>01</strong> Inscription</span><span><strong>02</strong> Dépôt de l’annonce</span><span><strong>03</strong> Validation E.G.K SARL</span></div></div></section>
    <section className="section section--sand"><div className="container owner-listing-layout">
      {!owner.data ? <div className="owner-access-card"><div className="owner-access-card__icon"><KeyRound size={22} /></div><span className="eyebrow">Espace propriétaire</span><h2>{mode === "register" ? "Créer votre compte" : "Se connecter"}</h2><p>{mode === "register" ? "Inscrivez-vous avant de transmettre votre première annonce." : "Retrouvez votre espace propriétaire pour déposer une annonce."}</p><div className="owner-access-tabs"><button type="button" className={mode === "register" ? "is-active" : ""} onClick={() => { setMode("register"); setError(""); }}><UserPlus size={16} /> Inscription</button><button type="button" className={mode === "login" ? "is-active" : ""} onClick={() => { setMode("login"); setError(""); }}><LogIn size={16} /> Connexion</button></div><form className="owner-access-form" onSubmit={submitAccess}>
        {mode === "register" && <><label>Nom complet<input name="fullName" required autoComplete="name" placeholder="Nom et prénom" /></label><label>Téléphone<input name="phone" required autoComplete="tel" inputMode="tel" placeholder="+225 …" /></label></>}
        <label>E-mail<input name="email" type="email" required autoComplete="email" placeholder="vous@exemple.ci" /></label>
        <label>Mot de passe<input name="password" type="password" required minLength={8} autoComplete={mode === "register" ? "new-password" : "current-password"} placeholder="8 caractères minimum" /></label>
        {mode === "register" && <label>Confirmer le mot de passe<input name="passwordConfirmation" type="password" required minLength={8} autoComplete="new-password" placeholder="Répétez le mot de passe" /></label>}
        {error && <p className="form-error" role="alert">{error}</p>}
        <button className="button button--gold" type="submit" disabled={isAccessPending}>{isAccessPending ? "Connexion en cours…" : mode === "register" ? <><UserPlus size={17} /> Créer mon compte</> : <><LogIn size={17} /> Ouvrir mon espace</>}</button>
      </form><small>Vos identifiants servent uniquement à gérer vos annonces immobilières auprès d’E.G.K SARL.</small></div> : <div className="owner-connected-card"><div><span className="eyebrow">Compte propriétaire connecté</span><h2>Bonjour, {owner.data.fullName}</h2><p>{owner.data.email}</p></div><button type="button" className="button button--outline" onClick={() => logout.mutate()} disabled={logout.isPending}><LogOut size={16} /> Se déconnecter</button></div>}
      <div className="owner-listing-intro"><Building2 size={28} /><span className="eyebrow">Après validation</span><h2>Votre annonce sera publiée dans Immobilier & BTP.</h2><ul><li><CheckCircle2 size={17} /> L’administration vérifie les informations et les consentements de contact.</li><li><CheckCircle2 size={17} /> Le bien n’apparaît au public qu’après le statut « Publié ».</li><li><CheckCircle2 size={17} /> Vous pouvez revenir déposer d’autres biens avec le même compte.</li></ul></div>
    </div></section>
    {owner.data && <section className="section section--ink"><div className="container"><RequestForm requestType="general" serviceSlug={PROPERTY_LISTING_SERVICE_SLUG} title="Déposer votre annonce immobilière" intro="Renseignez les caractéristiques du bien. L’équipe E.G.K SARL examinera votre annonce avant toute publication publique." extraFieldsOverride={propertyListingFields} propertyOwnerMode /></div></section>}
  </PublicLayout>;
}
