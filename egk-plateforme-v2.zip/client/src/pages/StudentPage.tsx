import { BookOpenCheck, ClipboardCheck, GraduationCap, LockKeyhole, PlayCircle, UserRound } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import PageMeta from "@/components/PageMeta";
import { useAuth } from "@/_core/hooks/useAuth";

const learningBlocks = [
  { icon: BookOpenCheck, title: "Mes formations", text: "Les formations attribuées apparaîtront ici après publication par le responsable pédagogique." },
  { icon: PlayCircle, title: "Cours & ressources", text: "Vidéos, documents, exercices et évaluations seront accessibles selon votre parcours." },
  { icon: ClipboardCheck, title: "Progression", text: "Le suivi pédagogique et les informations administratives seront centralisés dans cet espace." },
];

export default function StudentPage() {
  const { user } = useAuth();
  const isStudent = user?.role === "student";
  return <DashboardLayout><PageMeta title="Espace étudiant" description="Espace de formation EGK réservé aux utilisateurs authentifiés." />
    <div className="student-page"><header><div><span className="eyebrow">Institut EGK</span><h1>Bonjour{user?.name ? `, ${user.name}` : ""}.</h1><p>Votre espace étudiant prépare l’accès à vos formations, ressources et informations pédagogiques.</p></div><div className="student-page__badge"><UserRound size={18} />{isStudent ? "Compte étudiant" : "Espace sécurisé"}</div></header>{!isStudent && <div className="student-page__notice"><LockKeyhole size={19} /><span>Votre compte est authentifié, mais il doit être associé au rôle « étudiant » par l’administration EGK pour accéder à des formations personnalisées.</span></div>}<section className="student-blocks">{learningBlocks.map(block => { const Icon = block.icon; return <article key={block.title}><Icon size={23} /><h2>{block.title}</h2><p>{block.text}</p><span>En préparation</span></article>})}</section><section className="student-page__footer"><GraduationCap size={25} /><div><strong>Une plateforme d’apprentissage construite progressivement.</strong><p>La base sécurisée, les rôles et les modules de contenu sont prêts à être complétés par les filières, cours et documents officiels d’EGK.</p></div></section></div>
  </DashboardLayout>;
}
