import { ArrowRight, ArrowUpRight, Building2, Check, Compass, GraduationCap, Landmark, MapPin, MoveRight, Sprout } from "lucide-react";
import { Link } from "wouter";
import PageMeta from "@/components/PageMeta";
import PublicLayout from "@/components/PublicLayout";
import { catalogItems, heroImageUrl, sectors, serviceCards } from "@/lib/siteData";
import { getRequestFormHref } from "@shared/requestFormRouting";
import { TRAINING_ENROLLMENT_CONTACT_HREF } from "@shared/trainingContact";

const editorialCards = [
  { label: "Immobilier & BTP", title: "Penser l’accès à la propriété autrement", description: "Une présentation claire des modèles de maisons, préinscriptions et informations à valider avant engagement.", href: "/catalogue/property", Icon: Building2 },
  { label: "Institut EGK", title: "Se former pour aller plus loin", description: "Filières, programmes, inscriptions et future plateforme d’apprentissage réunis au même endroit.", href: "/formation", Icon: GraduationCap },
  { label: "Territoires", title: "Produire, relier, développer", description: "Agriculture, élevage, transport, salubrité : des pôles pensés pour les besoins du quotidien.", href: "/agriculture", Icon: Compass },
];

export default function Home() {
  return (
    <PublicLayout>
      <PageMeta title="Accueil" description="EGK rassemble des services de finance, immobilier, formation, agriculture, gastronomie et développement à Divo et dans le Gôh-Djiboua." />
      <section className="hero">
        <img className="hero__image" src={heroImageUrl} alt="Illustration éditoriale représentant plusieurs activités de développement" />
        <div className="hero__veil" />
        <div className="hero__grain" />
        <div className="container hero__content">
          <h1>Des solutions <em>pour aujourd’hui.</em><br />Des projets <em>pour demain.</em></h1>
          <p>EGK réunit finance, immobilier, formation, agriculture, gastronomie et services pour accompagner les besoins des personnes, des organisations et des territoires.</p>
          <div className="hero__actions"><Link href="/nos-services" className="button button--gold">Découvrir nos activités <ArrowUpRight size={17} /></Link><Link href={getRequestFormHref("general")} className="button button--ghost">Demander un service <ArrowRight size={17} /></Link></div>
        </div>
        <div className="hero__scroll"><span>Explorer</span><i /></div>
      </section>

      <section className="intro-section section">
        <div className="container intro-grid">
          <div><span className="eyebrow">Une même plateforme, des parcours utiles</span><h2>Rassembler les opportunités.<br /><em>Faciliter les projets.</em></h2></div>
          <div className="intro-grid__copy"><p>EGK est pensée comme une structure de proximité capable de faire dialoguer plusieurs secteurs d’activité. Cette vitrine présente les services, projets et points de contact au sein d’une expérience simple, adaptée au mobile.</p><Link href="/a-propos" className="text-link">Découvrir la vision EGK <MoveRight size={18} /></Link></div>
        </div>
      </section>

      <section className="services-section section section--sand">
        <div className="container"><div className="section-heading"><div><span className="eyebrow">Les univers EGK</span><h2>Des activités qui se répondent.</h2></div><Link href="/nos-services" className="text-link">Voir tous les secteurs <ArrowRight size={18} /></Link></div>
          <div className="service-bento">
            {serviceCards.map((sector, index) => { const Icon = sector.Icon; const href = sector.slug === "education" ? "/manuels" : sector.slug === "solidarite" ? "/finance" : `/${sector.slug}`; return <Link key={sector.slug} href={href} className={`service-card service-card--${index + 1}`}><span className="service-card__number">0{index + 1}</span><div className="service-card__icon"><Icon size={23} /></div><div><h3>{sector.title}</h3><p>{sector.description}</p></div><ArrowUpRight className="service-card__arrow" size={19} /></Link>; })}
          </div>
        </div>
      </section>

      <section className="section signature-section">
        <div className="container signature-grid"><div className="signature-grid__story"><span className="eyebrow eyebrow--gold">Le mouvement EGK</span><h2>Des projets enracinés dans <em>la vie réelle.</em></h2><p>Rechercher un logement, démarrer une formation, construire une maison, accéder à une information utile, réserver un espace : chaque parcours est conçu pour être compréhensible et accessible.</p><Link href={getRequestFormHref("general")} className="button button--sand">Parler à l’équipe EGK <ArrowUpRight size={17} /></Link></div><div className="signature-grid__quote"><Landmark size={34} /><blockquote>« Une plateforme pour présenter les projets, faciliter la mise en relation et grandir progressivement avec les besoins. »</blockquote><span>— Ambition numérique EGK</span></div></div>
      </section>

      <section className="section projects-section"><div className="container"><div className="section-heading"><div><span className="eyebrow">À la une</span><h2>Les projets à suivre.</h2></div><span className="heading-note">Des espaces évolutifs, administrables par l’équipe EGK.</span></div><div className="editorial-grid">{editorialCards.map(({ label, title, description, href, Icon }) => <article key={label} className="editorial-card"><div className="editorial-card__top"><span>{label}</span><Icon size={24} /></div><h3>{title}</h3><p>{description}</p><Link href={href} className="editorial-card__link">Explorer <ArrowUpRight size={18} /></Link></article>)}</div></div></section>

      <section className="catalog-preview section section--ink"><div className="container"><div className="catalog-preview__heading"><div><span className="eyebrow eyebrow--gold">Catalogues EGK</span><h2>Consulter.<br /><em>Se renseigner.</em></h2></div><p>Des interfaces dédiées aux modèles immobiliers, productions et futures lignes de transport, avec des fiches administrables et une prise de contact immédiate.</p></div><div className="catalog-preview__items">{catalogItems.slice(0, 4).map((item, index) => <Link href={`/catalogue/${item.kind}/${item.slug}`} key={item.slug} className="catalog-teaser"><span>0{index + 1}</span><div><small>{item.kicker}</small><h3>{item.title}</h3><p>{item.availability}</p></div><ArrowUpRight size={21} /></Link>)}</div></div></section>

      <section className="section quick-actions"><div className="container quick-actions__grid"><div><span className="eyebrow">Un besoin précis ?</span><h2>Commencez par une demande simple.</h2><p>Choisissez le service qui vous intéresse et décrivez votre besoin. L’équipe EGK pourra ensuite vous orienter vers le bon interlocuteur.</p></div><div className="quick-actions__links"><Link href={getRequestFormHref("general")}><span><Check size={17} /> Demande générale</span><ArrowUpRight size={20} /></Link><Link href={getRequestFormHref("construction", "immobilier-btp")}><span><Check size={17} /> Construction ou logement</span><ArrowUpRight size={20} /></Link><Link href={TRAINING_ENROLLMENT_CONTACT_HREF}><span><Check size={17} /> Formation ou inscription</span><ArrowUpRight size={20} /></Link><Link href="/a-propos#formulaire-contact"><span><Check size={17} /> Message à EGK</span><ArrowUpRight size={20} /></Link></div></div></section>

    </PublicLayout>
  );
}
