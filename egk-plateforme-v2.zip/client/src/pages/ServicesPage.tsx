import { ArrowUpRight, Check, Sparkles } from "lucide-react";
import { Link } from "wouter";
import PageMeta from "@/components/PageMeta";
import PublicLayout from "@/components/PublicLayout";
import { serviceCards } from "@/lib/siteData";
import { getRequestFormHref } from "@shared/requestFormRouting";

export default function ServicesPage() {
  return <PublicLayout><PageMeta title="Nos activités" description="Explorez les secteurs d’activité, services et projets que rassemble la plateforme EGK." />
    <section className="services-hero"><div className="container"><span className="eyebrow eyebrow--gold">Tous les secteurs</span><h1>Une plateforme.<br /><em>Des réponses multiples.</em></h1><p>Découvrez les univers EGK et choisissez le parcours le plus proche de votre besoin. Chaque rubrique contient une présentation, des informations utiles et une possibilité de mise en relation.</p></div></section>
    <section className="section"><div className="container"><div className="service-directory">{serviceCards.map((sector, index) => { const Icon = sector.Icon; const href = sector.slug === "education" ? "/manuels" : sector.slug === "solidarite" ? "/finance" : `/${sector.slug}`; return <Link href={href} className="service-directory__item" key={sector.slug}><span className="service-directory__number">0{index + 1}</span><div className="service-directory__icon"><Icon size={24} /></div><div><h2>{sector.title}</h2><p>{sector.description}</p><span className="service-directory__action">Explorer ce secteur <ArrowUpRight size={17} /></span></div></Link> })}</div></div></section>
    <section className="section section--sand"><div className="container services-note"><Sparkles size={26} /><div><span className="eyebrow">Un besoin transversal ?</span><h2>Vous ne savez pas encore vers quel service vous orienter ?</h2><p>Commencez par une demande générale : EGK pourra étudier votre besoin et l’adresser au pôle concerné.</p></div><Link href={getRequestFormHref("general")} className="button button--dark"><Check size={17} /> Faire une demande générale</Link></div></section>
  </PublicLayout>;
}
