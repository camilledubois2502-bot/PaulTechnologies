import { ArrowRight, ArrowUpRight, Building2, Download, Handshake, School, Sparkles } from "lucide-react";
import { useEffect, useLayoutEffect, useMemo, useState } from "react";
import { Link, useSearch } from "wouter";
import PageMeta from "@/components/PageMeta";
import PublicLayout from "@/components/PublicLayout";
import RequestForm from "@/components/RequestForm";
import { PROPERTY_LISTING_SERVICE_SLUG, PROPERTY_OWNER_LISTING_HREF, RENTAL_REQUEST_FORM_PDF_URL, sectorBySlug, type RequestType } from "@/lib/siteData";
import { getRequestFormContext } from "@shared/requestFormRouting";

const requestOptions: { type: RequestType; title: string; description: string }[] = [
  { type: "general", title: "Demande générale", description: "Un besoin transversal ou une orientation à recevoir." },
  { type: "finance", title: "Financement", description: "Microcrédit, co-crédit ou solidarité." },
  { type: "construction", title: "Construction", description: "Un projet de maison, terrain ou accompagnement BTP." },
  { type: "rental", title: "Location", description: "Une recherche de logement ou une demande d’information." },
  { type: "training", title: "Formation", description: "Une inscription, une filière ou un programme." },
  { type: "teacher_application", title: "Candidature enseignant", description: "Une candidature pour rejoindre l’Institut EGK." },
  { type: "btp_partner", title: "Partenariat BTP", description: "Une candidature de professionnel ou d’entreprise." },
  { type: "reservation", title: "Réservation", description: "Un événement ou un espace du Village gastronomique." },
  { type: "sanitation", title: "Salubrité", description: "Une intervention de nettoyage ou de collecte." },
];

export default function RequestPage() {
  const search = useSearch();
  const requestContext = useMemo(() => getRequestFormContext(search), [search]);
  const [activeType, setActiveType] = useState<RequestType>(() => requestContext.requestType);
  const activeOption = requestOptions.find(option => option.type === activeType) ?? requestOptions[0];
  const sourceSector = sectorBySlug[requestContext.serviceSlug];
  const isPropertyListing = activeType === "general" && requestContext.serviceSlug === PROPERTY_LISTING_SERVICE_SLUG;
  const isSourceContextActive = activeType === requestContext.requestType && Boolean(sourceSector);
  const serviceSlug = isPropertyListing ? PROPERTY_LISTING_SERVICE_SLUG : isSourceContextActive ? requestContext.serviceSlug : activeType;
  const isRentalSearch = activeType === "rental" && (serviceSlug === "location-maisons" || serviceSlug === "rental");
  const formTitle = isPropertyListing ? "Déposez votre annonce immobilière" : isRentalSearch ? "Faites connaître votre recherche de logement" : isSourceContextActive ? sourceSector.requestTitle : activeOption.title;
  const formIntro = isPropertyListing ? "Créez un compte propriétaire pour déposer votre annonce et la transmettre à l’administration E.G.K SARL pour approbation." : isRentalSearch ? "Consultez les logements disponibles grâce aux filtres immobiliers. Si aucun bien ne correspond à vos critères, indiquez ici votre recherche afin qu’E.G.K SARL puisse vous recontacter." : isSourceContextActive ? `Votre demande concerne le pôle ${sourceSector.navigationTitle}. Renseignez les éléments essentiels afin que l’équipe EGK puisse vous recontacter.` : activeOption.description;

  useEffect(() => setActiveType(requestContext.requestType), [requestContext.requestType]);

  useLayoutEffect(() => {
    if (!search) return;
    const form = document.getElementById("formulaire-demande");
    if (form) window.scrollTo({ top: form.getBoundingClientRect().top + window.scrollY - 72, behavior: "auto" });
  }, [search]);

  return <PublicLayout><PageMeta title="Demander un service" description="Transmettez une demande générale à EGK et soyez orienté vers le service concerné." />
  <section className="request-page-hero"><div className="container"><div><span className="eyebrow eyebrow--gold">Service de mise en relation</span><h1>Votre besoin mérite<br />un <em>bon point de départ.</em></h1><p>Décrivez votre demande en quelques informations. EGK pourra étudier votre situation et revenir vers vous avec l’orientation adaptée.</p></div><div className="request-page-hero__steps"><span>01 <i /> Décrivez</span><span>02 <i /> Étude</span><span>03 <i /> Orientation</span></div></div></section>
  <section className="section"><div className="container"><div className="request-choice-heading"><span className="eyebrow">Choisissez un parcours</span><h2>Quel est votre besoin aujourd’hui ?</h2></div><div className="request-options">{requestOptions.map(option => <button type="button" className={activeType === option.type ? "is-active" : ""} onClick={() => setActiveType(option.type)} key={option.type}><strong>{option.title}</strong><span>{option.description}</span><ArrowUpRight size={17} /></button>)}</div></div></section>
  <section id="formulaire-demande" className="section section--ink"><div className="container">{isRentalSearch && <div className="rental-request-download"><div><span className="eyebrow eyebrow--gold">Formulaire imprimable</span><strong>Préférez-vous remplir votre demande à la main&nbsp;?</strong><p>Téléchargez le formulaire PDF, complétez-le puis transmettez-le à E.G.K SARL.</p></div><a href={RENTAL_REQUEST_FORM_PDF_URL} download className="button button--outline"><Download size={17} /> Télécharger le formulaire</a></div>}{isPropertyListing ? <div className="property-listing-redirect"><span className="eyebrow eyebrow--gold">Espace propriétaire</span><h2>Inscription obligatoire avant le dépôt.</h2><p>Pour protéger les propriétaires et permettre le suivi de chaque annonce, vous devez créer un compte ou vous connecter avant de renseigner le bien.</p><Link href={PROPERTY_OWNER_LISTING_HREF} className="button button--gold">Publier une annonce <ArrowRight size={17} /></Link></div> : <RequestForm requestType={activeType} serviceSlug={serviceSlug} title={formTitle} intro={formIntro} />}</div></section>
</PublicLayout> }
