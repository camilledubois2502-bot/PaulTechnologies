import { Route, Switch, useParams } from "wouter";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import SectorPage from "./pages/SectorPage";
import { CatalogDetailPage, CatalogListPage } from "./pages/CatalogPage";
import { AboutContactPage, GalleryDetailPage, GalleryPage, ManualsPage } from "./pages/InformationPages";
import RequestPage from "./pages/RequestPage";
import AdminPage from "./pages/AdminPage";
import PropertyOwnerListingPage from "./pages/PropertyOwnerListingPage";
import ServicesPage from "./pages/ServicesPage";
import StudentPage from "./pages/StudentPage";
import NotFound from "./pages/NotFound";
import type { CatalogKind } from "@/lib/siteData";

const catalogKinds = ["property", "agriculture", "livestock", "transport"] as const;
function isCatalogKind(value: string | undefined): value is CatalogKind { return catalogKinds.includes(value as CatalogKind); }

function CatalogListRoute() {
  const { kind } = useParams<{ kind: string }>();
  return isCatalogKind(kind) ? <CatalogListPage kind={kind} /> : <NotFound />;
}

function CatalogDetailRoute() {
  const { kind, slug } = useParams<{ kind: string; slug: string }>();
  return isCatalogKind(kind) && slug ? <CatalogDetailPage kind={kind} slug={slug} /> : <NotFound />;
}

function GalleryDetailRoute() {
  const { slug } = useParams<{ slug: string }>();
  return slug ? <GalleryDetailPage slug={slug} /> : <NotFound />;
}

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/a-propos" component={AboutContactPage} />
    <Route path="/nos-services" component={ServicesPage} />
    <Route path="/finance" component={() => <SectorPage sectorSlug="finance" />} />
    <Route path="/immobilier-btp" component={() => <SectorPage sectorSlug="immobilier-btp" />} />
    <Route path="/formation" component={() => <SectorPage sectorSlug="formation" />} />
    <Route path="/agriculture" component={() => <SectorPage sectorSlug="agriculture" />} />
    <Route path="/elevage" component={() => <SectorPage sectorSlug="elevage" />} />
    <Route path="/gastronomie" component={() => <SectorPage sectorSlug="gastronomie" />} />
    <Route path="/transport" component={() => <SectorPage sectorSlug="transport" />} />
    <Route path="/salubrite" component={() => <SectorPage sectorSlug="salubrite" />} />
    <Route path="/catalogue/:kind/:slug" component={CatalogDetailRoute} />
    <Route path="/catalogue/:kind" component={CatalogListRoute} />
    <Route path="/manuels" component={ManualsPage} />
    <Route path="/galerie/:slug" component={GalleryDetailRoute} />
    <Route path="/galerie" component={GalleryPage} />
    <Route path="/contact" component={AboutContactPage} />
    <Route path="/demander-un-service" component={RequestPage} />
    <Route path="/administration" component={AdminPage} />
    <Route path="/proprietaire/annonce" component={PropertyOwnerListingPage} />
    <Route path="/espace-etudiant" component={StudentPage} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
