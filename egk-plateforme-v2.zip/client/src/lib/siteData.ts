import type { ComponentType } from "react";
import {
  Banknote,
  BookOpen,
  Building2,
  BusFront,
  HandHeart,
  Home,
  Leaf,
  School,
  Soup,
  Sprout,
  Truck,
  type LucideProps,
} from "lucide-react";
import type { RequestFormType } from "@shared/requestFormRouting";
export { EGK_WHATSAPP_NUMBER, getWhatsAppHref, getWhatsAppMessage } from "@shared/whatsapp";

export type RequestType = RequestFormType;

type Sector = {
  slug: string;
  title: string;
  navigationTitle: string;
  eyebrow: string;
  description: string;
  intro: string;
  focus: string[];
  projects: { name: string; description: string }[];
  requestType: RequestType;
  requestTitle: string;
  requestCta: string;
  Icon: ComponentType<LucideProps>;
  accent: string;
};

export const brandName = "E.G.K SARL";
export const legalName = "E.G.K SARL";
export const legalAddress = "Divo, Quartier Grémian — ancien marché, à proximité de l’hôtel « le rocher », immeuble dix-huit un mec bien";
export const rccmNumber = "CI-DIV-01-2026-B12-00056";
export const siteName = brandName;
export const siteTagline = "Pureté · Intégrité · Justice · Dignité";
export const ADMINISTRATION_HREF = "/administration";
export const PUBLIC_NAVIGATION_MODE = "menu-only" as const;
export const brandLogoUrl = "/manus-storage/egk-sarl-logo-horizontal-corrected_3aec37c8.png";
export const heroImageUrl = "/manus-storage/egk-hero-services_94f4a9c8.jpg";
export const trainingPosterUrl = "/manus-storage/gk-formation-filieres_68925fbf.webp";
export const trainingStudentsUrl = "/manus-storage/gk-formation-etudiants-alpha_4d6bcc1a.png";
export const trainingProgrammes = [
  "Agropastoral",
  "Bilingue",
  "Esthétique",
  "Sanitaire Social",
  "Bâtiments",
  "BTP",
  "Communications AudioVisuelle",
  "Caissier/Caissière",
  "Informatiques",
  "Géomètre Topographe",
] as const;
/** Transcription fidèle des intitulés visibles sur l’affiche GK Formation transmise par E.G.K SARL. Voir TRAINING_PROGRAMMES_SOURCE.md. */
export const trainingProgrammesSource = "Filières transcrites depuis l’affiche GK Formation transmise par E.G.K SARL";
export const trainingContacts = ["+225 07 79 35 08 38", "+225 07 05 46 99 19", "+225 07 08 23 79 15"];
export const manualTitleCatalogue = [
  { title: "DICTÉE 6EME", category: "Français", level: "6e" },
  { title: "DICTÉE 5EME", category: "Français", level: "5e" },
  { title: "DICTÉE CP1 · CP2 · CM1 · CM2", category: "Français", level: "Primaire" },
  { title: "PRO DES MATHS — tous niveaux", category: "Mathématiques", level: "Tous niveaux" },
  { title: "Mémo Philo", category: "Philosophie", level: "Terminale" },
  { title: "Carnet de correspondance", category: "Vie scolaire", level: "Tous niveaux" },
] as const;
export type ManualLevelFilter = "all" | (typeof manualTitleCatalogue)[number]["level"];

export function filterManualTitleCatalogue(query: string, level: ManualLevelFilter) {
  const normalizedQuery = query.trim().toLocaleLowerCase("fr-FR");
  return manualTitleCatalogue.filter(manual => {
    const matchesLevel = level === "all" || manual.level === level;
    const searchable = `${manual.title} ${manual.category} ${manual.level}`.toLocaleLowerCase("fr-FR");
    return matchesLevel && (!normalizedQuery || searchable.includes(normalizedQuery));
  });
}
export const financeProductsPosterUrl = "/manus-storage/egk-finance-produits_575db5cf.png";
export const financeProducts = [
  {
    label: "Produit I",
    title: "Extension Business",
    description: "Un financement pour développer votre petite activité et la transformer en une grande entreprise.",
    details: [
      "Montant disponible : 50 000 F à 200 000 F CFA selon votre activité et votre capacité de remboursement.",
      "Remboursement sur 7 mois à partir d’un montant journalier perçu sur 5 jours/semaine.",
      "Ouvrez un compte d’épargne et épargnez régulièrement pour accéder à des montants plus importants.",
    ],
  },
  {
    label: "Produit II",
    title: "Paie mon École",
    description: "Anticipez l’avenir de vos enfants en toute tranquillité.",
    details: [
      "Épargnez pendant 9 mois sur la base de la scolarité de l’école visée.",
      "À la rentrée, EGK-SARL prend en charge l’inscription et la scolarité de votre enfant.",
      "Vous ne payez que l’inscription en ligne et les frais annexes.",
    ],
  },
  {
    label: "Produit III",
    title: "Vacances Libres",
    description: "Des vacances sans dettes, en toute liberté !",
    details: [
      "Épargnez selon l’aide souhaitée pendant trois mois de vacances : juin, juillet et août.",
      "Offre Soulagement : 50 000 F / mois pendant 3 mois.",
      "Offre Providence : 60 000 F / mois pendant 3 mois.",
      "Offre Satisfaction : 75 000 F / mois pendant 3 mois.",
      "Le préalable pour bénéficier de tous ces produits est d’avoir un compte ouvert dans notre service Micro Crédit et Solidarité.",
    ],
  },
] as const;
/** Conditions transcrites panneau par panneau depuis le support produits Finance ; voir FINANCE_PRODUCTS_OCR_TRANSCRIPT.md. */
export const financeProductsSource = "Transcription du support EGK-SARL — Service Micro Crédit et Solidarité";

export const navigationItems = [
  { label: "Accueil", href: "/" },
  { label: "À propos & Contact", href: "/a-propos" },
  { label: "Finance", href: "/finance" },
  { label: "Immobilier & BTP", href: "/immobilier-btp" },
  { label: "Formation", href: "/formation" },
  { label: "Agriculture", href: "/agriculture" },
  { label: "Élevage", href: "/elevage" },
  { label: "Gastronomie", href: "/gastronomie" },
  { label: "Transport", href: "/transport" },
  { label: "Salubrité", href: "/salubrite" },
  { label: "Galerie", href: "/galerie" },
];

export const sectors: Sector[] = [
  {
    slug: "finance",
    title: "Finance & solidarité",
    navigationTitle: "Finance",
    eyebrow: "Des parcours à étudier avec attention",
    description: "Microcrédit, co-crédit et solidarité pour accompagner des projets et besoins admissibles.",
    intro: "EGK prévoit une information claire sur ses solutions financières, leurs conditions, les pièces attendues et les étapes d’étude. Chaque demande est analysée selon le dispositif concerné.",
    focus: ["Microcrédit", "Co-crédit", "Programme de solidarité", "Accompagnement des demandes"],
    projects: [
      { name: "Parcours de demande", description: "Une demande structurée, destinée à faciliter une première analyse du besoin." },
      { name: "Information transparente", description: "Des conditions et modalités à publier et actualiser par l’équipe EGK." },
    ],
    requestType: "finance",
    requestTitle: "Présenter votre besoin de financement",
    requestCta: "Faire une demande",
    Icon: Banknote,
    accent: "finance",
  },
  {
    slug: "immobilier-btp",
    title: "Immobilier & BTP",
    navigationTitle: "Immobilier & BTP",
    eyebrow: "Construire, habiter, développer",
    description: "Location, accompagnement à la construction, réseau de professionnels et modèles de maison.",
    intro: "Cette rubrique rassemble les parcours immobiliers et BTP d’EGK : recherche de logement, accompagnement pour construire, mise en relation avec des professionnels et présentation de modèles de maison.",
    focus: ["Location de maisons", "Construction de maisons", "Professionnels partenaires", "Modèles de maison"],
    projects: [
      { name: "Modèles de maison", description: "Une page de présentation dédiée aux modèles, aux conditions indicatives et à la préinscription." },
      { name: "Construire ma maison", description: "Un parcours de demande pour décrire un terrain, un budget et les besoins du projet." },
    ],
    requestType: "construction",
    requestTitle: "Parlez-nous de votre projet immobilier",
    requestCta: "Demander un accompagnement",
    Icon: Building2,
    accent: "real-estate",
  },
  {
    slug: "formation",
    title: "Formation & institut",
    navigationTitle: "Formation",
    eyebrow: "Apprendre pour progresser",
    description: "Filières, programmes, inscription, recrutement d’enseignants et futur espace étudiant.",
    intro: "L’Institut de formation EGK a vocation à présenter ses filières, programmes, admissions et calendrier. La plateforme prépare également un espace étudiant pour les ressources, cours et suivis pédagogiques.",
    focus: ["Institut de formation", "Filières et programmes", "Inscription en ligne", "Espace étudiant"],
    projects: [
      { name: "Inscription en ligne", description: "Un parcours simple pour transmettre une demande d’inscription et être recontacté." },
      { name: "Formation en ligne", description: "Une fondation pour les cours, documents, exercices et progression des étudiants." },
    ],
    requestType: "training",
    requestTitle: "Préparer votre inscription",
    requestCta: "Demander une inscription",
    Icon: School,
    accent: "training",
  },
  {
    slug: "agriculture",
    title: "Agriculture",
    navigationTitle: "Agriculture",
    eyebrow: "Produire avec méthode",
    description: "Sites de production, cultures, activités et futures fiches de produits disponibles.",
    intro: "EGK prépare une présentation structurée de ses sites de production, cultures, activités de terrain et produits destinés à la commercialisation. Les disponibilités sont publiées au fur et à mesure par l’équipe responsable.",
    focus: ["Sites de production", "Cultures", "Productions", "Commercialisation"],
    projects: [
      { name: "Fiches produits", description: "Un catalogue conçu pour afficher les caractéristiques, disponibilités et modalités de contact." },
      { name: "Activités de terrain", description: "Une section éditoriale pour valoriser les projets, saisons et réalisations agricoles." },
    ],
    requestType: "general",
    requestTitle: "Vous souhaitez en savoir plus sur nos productions ?",
    requestCta: "Contacter l’équipe agriculture",
    Icon: Sprout,
    accent: "agriculture",
  },
  {
    slug: "elevage",
    title: "Élevage",
    navigationTitle: "Élevage",
    eyebrow: "Développer des filières responsables",
    description: "Sites, activités, cheptel et productions destinées à la commercialisation.",
    intro: "Cette rubrique est préparée pour présenter les activités d’élevage, les sites concernés, les productions disponibles et les informations utiles à une mise en relation avec EGK.",
    focus: ["Sites d’élevage", "Activités", "Productions", "Commercialisation"],
    projects: [
      { name: "Catalogue des productions", description: "Des fiches claires pour publier les produits, conditions de disponibilité et contacts." },
      { name: "Valorisation des filières", description: "Une présentation évolutive des activités et du développement du pôle élevage." },
    ],
    requestType: "general",
    requestTitle: "Parlons des activités d’élevage",
    requestCta: "Contacter l’équipe élevage",
    Icon: Leaf,
    accent: "livestock",
  },
  {
    slug: "gastronomie",
    title: "Village gastronomique",
    navigationTitle: "Gastronomie",
    eyebrow: "Recevoir, découvrir, célébrer",
    description: "Un projet d’espaces de restauration, de détente et d’événements à Divo.",
    intro: "Le Village gastronomique EGK est pensé comme un futur lieu de rencontre, de restauration et d’événements. La plateforme prépare la présentation des espaces, des concepts et des demandes de réservation.",
    focus: ["Restaurants", "Spécialités", "Espaces de détente", "Salles événementielles"],
    projects: [
      { name: "Espaces événementiels", description: "Une présentation dédiée aux salles de mariage, conférences, VIP et autres configurations." },
      { name: "Réservation", description: "Un formulaire de prise de besoin pour événements, dates et configurations souhaitées." },
    ],
    requestType: "reservation",
    requestTitle: "Réserver ou préparer un événement",
    requestCta: "Demander une réservation",
    Icon: Soup,
    accent: "gastronomy",
  },
  {
    slug: "transport",
    title: "Transport",
    navigationTitle: "Transport",
    eyebrow: "Relier les territoires",
    description: "Une rubrique conçue pour présenter les lignes, horaires, tarifs et informations pratiques à venir.",
    intro: "Le pôle transport est préparé pour évoluer progressivement : les lignes, trajets, horaires, tarifs et disponibilités pourront être administrés facilement dès leur publication officielle.",
    focus: ["Lignes de proximité", "Destinations", "Horaires", "Informations pratiques"],
    projects: [
      { name: "Catalogue des lignes", description: "Une interface dédiée aux départs, destinations, horaires et conditions de voyage." },
      { name: "Évolution territoriale", description: "Une architecture adaptée à l’ajout progressif de nouvelles dessertes." },
    ],
    requestType: "general",
    requestTitle: "Recevoir les informations sur le transport",
    requestCta: "Être recontacté",
    Icon: BusFront,
    accent: "transport",
  },
  {
    slug: "salubrite",
    title: "Salubrité & environnement",
    navigationTitle: "Salubrité",
    eyebrow: "Prendre soin des lieux de vie",
    description: "Nettoyage, collecte, sensibilisation, équipements et interventions de proximité.",
    intro: "EGK prépare une rubrique consacrée aux opérations de terrain, projets environnementaux et demandes d’intervention. Chaque besoin peut être décrit simplement avant une prise de contact par l’équipe concernée.",
    focus: ["Opérations de nettoyage", "Collecte", "Sensibilisation", "Interventions"],
    projects: [
      { name: "Demande d’intervention", description: "Un formulaire pour renseigner la localisation, le besoin, la date souhaitée et les informations utiles." },
      { name: "Actions environnementales", description: "Un espace éditorial pour présenter équipements, campagnes et réalisations." },
    ],
    requestType: "sanitation",
    requestTitle: "Demander une intervention",
    requestCta: "Décrire mon besoin",
    Icon: Truck,
    accent: "sanitation",
  },
];

export const sectorBySlug = Object.fromEntries(sectors.map(sector => [sector.slug, sector]));

export const serviceCards = [
  ...sectors,
  {
    slug: "education",
    title: "Manuels scolaires",
    navigationTitle: "Manuels scolaires",
    eyebrow: "Ressources pédagogiques",
    description: "Une future bibliothèque de consultation en ligne, organisée par catégories et niveaux.",
    intro: "",
    focus: [],
    projects: [],
    requestType: "general" as RequestType,
    requestTitle: "",
    requestCta: "Découvrir",
    Icon: BookOpen,
    accent: "education",
  },
  {
    slug: "solidarite",
    title: "Proximité & solidarité",
    navigationTitle: "Solidarité",
    eyebrow: "Accompagner les besoins",
    description: "Un volet d’information et de mise en relation pour les programmes de solidarité.",
    intro: "",
    focus: [],
    projects: [],
    requestType: "general" as RequestType,
    requestTitle: "",
    requestCta: "Nous contacter",
    Icon: HandHeart,
    accent: "solidarity",
  },
];

export type CatalogKind = "property" | "agriculture" | "livestock" | "transport";

export type CatalogItem = {
  kind: CatalogKind;
  listingType?: "Modèle" | "Location" | "Vente" | "Production" | "Ligne";
  slug: string;
  title: string;
  kicker: string;
  location: string;
  priceLabel: string;
  availability: string;
  description: string;
  attributes: { label: string; value: string }[];
  gallery?: { url: string; type: "image" | "video"; alt: string }[];
  ownerContactHref?: string;
  ownerEmail?: string;
  availabilityStatus?: "available" | "rented" | "sold";
  region?: string;
  city?: string;
  housingType?: string;
  monthlyRent?: number | null;
  isPublishedListing?: boolean;
  isRentalListing?: boolean;
  requestType: RequestType;
  sector: string;
};

export const catalogItems: CatalogItem[] = [
  {
    kind: "property", listingType: "Modèle", slug: "modele-2-chambres-salon", title: "Modèle 2 chambres + salon", kicker: "Modèle de maison indicatif", location: "Divo & zone de déploiement", priceLabel: "Conditions indicatives à publier", availability: "Préinscription possible", description: "Fiche de modèle conçue pour présenter le plan, la superficie, les caractéristiques et les conditions du programme après validation officielle.", attributes: [{ label: "Configuration", value: "2 chambres + salon" }, { label: "Plan", value: "À intégrer" }, { label: "Programme", value: "Modèle de maison" }], requestType: "construction", sector: "immobilier-btp",
  },
  {
    kind: "property", listingType: "Modèle", slug: "modele-3-chambres-salon", title: "Modèle 3 chambres + salon", kicker: "Modèle de maison indicatif", location: "Divo & zone de déploiement", priceLabel: "Conditions indicatives à publier", availability: "Préinscription possible", description: "Fiche de modèle prête à recevoir les photos, le plan, la superficie et les conditions de paiement validées par EGK.", attributes: [{ label: "Configuration", value: "3 chambres + salon" }, { label: "Plan", value: "À intégrer" }, { label: "Programme", value: "Modèle de maison" }], requestType: "construction", sector: "immobilier-btp",
  },
  {
    kind: "property", listingType: "Location", slug: "location-2-chambres-divo", title: "Location — 2 chambres + salon", kicker: "Annonce de location à compléter", location: "Divo · quartier à renseigner", priceLabel: "Loyer à publier", availability: "Disponibilité à confirmer", description: "Gabarit d’annonce dédié à la location, prêt à présenter les photos, la localisation précise, les conditions, les caractéristiques et le contact EGK.", attributes: [{ label: "Type", value: "Maison à louer" }, { label: "Configuration", value: "2 chambres + salon" }, { label: "Statut", value: "À publier" }], requestType: "rental", sector: "immobilier-btp",
  },
  {
    kind: "property", listingType: "Location", slug: "location-3-chambres-divo", title: "Location — 3 chambres + salon", kicker: "Annonce de location à compléter", location: "Divo · quartier à renseigner", priceLabel: "Loyer à publier", availability: "Disponibilité à confirmer", description: "Gabarit d’annonce dédié à la location avec les champs métier nécessaires : pièces, salon, situation, prix, disponibilité et informations de visite.", attributes: [{ label: "Type", value: "Maison à louer" }, { label: "Configuration", value: "3 chambres + salon" }, { label: "Statut", value: "À publier" }], requestType: "rental", sector: "immobilier-btp",
  },
  {
    kind: "agriculture", slug: "production-a-publier", title: "Production agricole", kicker: "Fiche de production à compléter", location: "Site de production à renseigner", priceLabel: "Sur demande", availability: "Disponibilité à confirmer", description: "Gabarit de fiche permettant à EGK de publier le nom du produit, la période de disponibilité, les volumes et les modalités de contact.", attributes: [{ label: "Catégorie", value: "À renseigner" }, { label: "Conditionnement", value: "À renseigner" }, { label: "Origine", value: "À renseigner" }], requestType: "general", sector: "agriculture",
  },
  {
    kind: "livestock", slug: "production-elevage-a-publier", title: "Production d’élevage", kicker: "Fiche de production à compléter", location: "Site d’élevage à renseigner", priceLabel: "Sur demande", availability: "Disponibilité à confirmer", description: "Gabarit de catalogue prêt à accueillir les productions, caractéristiques, disponibilités et conditions de commercialisation communiquées par EGK.", attributes: [{ label: "Type", value: "À renseigner" }, { label: "Condition", value: "À renseigner" }, { label: "Origine", value: "À renseigner" }], requestType: "general", sector: "elevage",
  },
  {
    kind: "transport", slug: "divo-doussou", title: "Divo – Doussou", kicker: "Ligne envisagée", location: "Divo / Doussou", priceLabel: "Tarif à publier", availability: "Informations à confirmer", description: "Fiche de ligne prête à afficher les horaires, tarifs, disponibilités et informations pratiques dès leur communication officielle.", attributes: [{ label: "Départ", value: "Divo" }, { label: "Destination", value: "Doussou" }, { label: "Horaires", value: "À publier" }], requestType: "general", sector: "transport",
  },
  {
    kind: "transport", slug: "divo-lakota-agniba", title: "Divo – Lakota – Agniba", kicker: "Ligne envisagée", location: "Divo / Lakota / Agniba", priceLabel: "Tarif à publier", availability: "Informations à confirmer", description: "Fiche de ligne évolutive pour présenter les points de passage, horaires et conditions de service après validation.", attributes: [{ label: "Départ", value: "Divo" }, { label: "Destination", value: "Agniba" }, { label: "Horaires", value: "À publier" }], requestType: "general", sector: "transport",
  },
];

export const catalogLabels: Record<CatalogKind, { title: string; intro: string; sector: string }> = {
  property: { title: "Immobilier & modèles", intro: "Consultez les modèles et fiches publiés par EGK. Les éléments indiqués comme indicatifs seront précisés par les informations officielles du programme.", sector: "immobilier-btp" },
  agriculture: { title: "Productions agricoles", intro: "Cette interface est prête à présenter les productions, disponibilités et conditions de mise en relation communiquées par EGK.", sector: "agriculture" },
  livestock: { title: "Productions d’élevage", intro: "Les fiches de production permettront de consulter les informations utiles avant toute prise de contact avec l’équipe EGK.", sector: "elevage" },
  transport: { title: "Lignes de transport", intro: "Les lignes, horaires et tarifs seront affichés et actualisés dès leur communication officielle par EGK.", sector: "transport" },
};

export const galleryCategories = ["BTP", "Formation", "Agriculture", "Élevage", "Gastronomie", "Transport", "Salubrité", "Événements", "Équipe", "Réalisations"];

export const galleryCollections = galleryCategories.map(title => ({
  title,
  slug: title.toLocaleLowerCase("fr-FR").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
  description: `Les médias officiels relatifs à « ${title} » seront publiés et organisés par l’administration EGK.`,
}));

export type RequestExtraField = { name: string; label: string; placeholder: string; type?: "text" | "date" | "number"; required?: boolean };

export const PROPERTY_LISTING_SERVICE_SLUG = "depot-annonce-immobiliere";
export const PROPERTY_OWNER_LISTING_HREF = "/proprietaire/annonce";
export const RENTAL_REQUEST_FORM_PDF_URL = "/manus-storage/formulaire-demande-location-egk-sarl_ef89775e.pdf";

export const propertyListingFields: RequestExtraField[] = [
  { name: "proprietaire", label: "Nom complet du propriétaire", placeholder: "Nom et prénom du propriétaire" },
  { name: "qualite", label: "Qualité du déposant", placeholder: "Propriétaire, mandataire ou agence" },
  { name: "typeBien", label: "Type de bien", placeholder: "Maison, appartement, terrain…" },
  { name: "statut", label: "Type d’annonce", placeholder: "Vente, location ou autre" },
  { name: "regionBien", label: "Région du bien", placeholder: "Ex. Gôh-Djiboua" },
  { name: "villeBien", label: "Ville du bien", placeholder: "Ex. Divo" },
  { name: "adresseBien", label: "Localisation du bien", placeholder: "Ville, quartier, repère utile" },
  { name: "prix", label: "Prix ou loyer souhaité", placeholder: "Montant indicatif", required: false },
  { name: "loyerMensuel", label: "Loyer mensuel", placeholder: "Montant mensuel en FCFA", type: "number", required: false },
  { name: "chambres", label: "Configuration", placeholder: "Ex. 3 chambres + salon", required: false },
  { name: "surface", label: "Surface ou superficie", placeholder: "Ex. 400 m²", required: false },
];

export const requestExtraFields: Record<RequestType, RequestExtraField[]> = {
  general: [],
  contact: [],
  finance: [{ name: "service", label: "Service recherché", placeholder: "Microcrédit, co-crédit, solidarité…" }, { name: "montant", label: "Montant souhaité", placeholder: "Montant indicatif" }],
  construction: [{ name: "terrain", label: "Localisation du terrain", placeholder: "Ville, quartier, village…" }, { name: "superficie", label: "Superficie", placeholder: "Ex. 400 m²" }, { name: "configuration", label: "Maison souhaitée", placeholder: "Ex. 3 chambres + salon" }, { name: "budget", label: "Budget estimatif", placeholder: "Budget indicatif" }],
  rental: [{ name: "profession", label: "Profession", placeholder: "Votre profession" }, { name: "secteurActivite", label: "Secteur d’activité", placeholder: "Votre domaine d’activité" }, { name: "regionRecherche", label: "Région dans laquelle vous recherchez une maison", placeholder: "Ex. Gôh-Djiboua" }, { name: "villeRecherche", label: "Ville dans laquelle vous souhaitez habiter", placeholder: "Ex. Divo" }, { name: "typeLogement", label: "Type de maison ou logement recherché", placeholder: "Maison, appartement, studio…" }, { name: "budgetLoyer", label: "Budget prévu pour le loyer", placeholder: "Montant mensuel maximum en FCFA", type: "number" }],
  training: [{ name: "filiere", label: "Filière souhaitée", placeholder: "Filière ou formation recherchée" }, { name: "niveau", label: "Niveau d’étude", placeholder: "Votre niveau actuel" }],
  teacher_application: [{ name: "specialite", label: "Spécialité", placeholder: "Matière ou domaine" }, { name: "experience", label: "Expérience", placeholder: "Nombre d’années ou résumé" }],
  btp_partner: [{ name: "entreprise", label: "Nom de l’entreprise", placeholder: "Nom de votre structure" }, { name: "competence", label: "Domaine de compétence", placeholder: "Maçonnerie, plomberie…" }, { name: "experience", label: "Expérience", placeholder: "Résumé de vos réalisations" }],
  reservation: [{ name: "evenement", label: "Type d’événement", placeholder: "Mariage, conférence…" }, { name: "date", label: "Date souhaitée", placeholder: "", type: "date" }, { name: "personnes", label: "Nombre de personnes", placeholder: "Ex. 80", type: "number" }, { name: "espace", label: "Espace souhaité", placeholder: "Salle, espace VIP…" }],
  sanitation: [{ name: "besoin", label: "Type de besoin", placeholder: "Nettoyage, collecte…" }, { name: "date", label: "Date souhaitée", placeholder: "", type: "date" }],
  fad_interest: [{ name: "modele", label: "Modèle envisagé", placeholder: "2, 3 ou 4 chambres + salon" }, { name: "apport", label: "Apport indicatif envisagé", placeholder: "Montant à titre indicatif" }],
};
