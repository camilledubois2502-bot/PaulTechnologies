# Vérification qualité — EGK

## Navigation et clavier

La navigation publique s’appuie sur des liens natifs et les menus utilisent des boutons. Les éléments interactifs possèdent des intitulés accessibles, notamment le menu mobile et le bouton WhatsApp. Avant publication, la personne responsable doit parcourir les pages avec les touches `Tab`, `Maj+Tab`, `Entrée` et `Échap` pour confirmer que le menu mobile, les filtres et les formulaires restent entièrement utilisables sans souris.

## Contraste et responsive

Les interfaces reposent sur des fonds vert forêt, sable et or, associés à des textes blancs ou vert foncé. Les rendus de l’accueil, d’une page sectorielle, du catalogue et du contact ont été contrôlés en desktop et mobile. Toute image ou média officiel ajouté ultérieurement doit préserver la lisibilité des textes superposés ; si nécessaire, conserver un voile ou un fond uni derrière le texte.

## Formulaires

Les formulaires exposent des libellés visibles, des champs requis, un retour d’état après envoi et une validation serveur. Les procédures de demande et les schémas de contenu sont couverts par Vitest. Avant publication, effectuer au moins un essai fonctionnel pour chaque service avec une adresse de test, puis supprimer ou traiter les données de test depuis l’administration.

## Documents pédagogiques

Les manuels sont référencés avec une clé de stockage non publique. Leur URL signée n’est délivrée qu’après authentification et contrôle d’un rôle `student`, `training_manager` ou `admin`. Les documents réels doivent être ajoutés par un responsable habilité et faire l’objet d’une vérification de droits de diffusion.

