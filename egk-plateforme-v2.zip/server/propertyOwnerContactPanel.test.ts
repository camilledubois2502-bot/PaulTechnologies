import { describe, expect, it } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { PropertyOwnerContactPanel } from "../client/src/components/PropertyOwnerContactPanel";
import { getPropertyOwnerContactHref } from "../shared/propertyListingContact";

describe("panneau de contact propriétaire", () => {
  it("rend le badge de contact WhatsApp et le formulaire e-mail pour une annonce publiée autorisée", () => {
    const html = renderToStaticMarkup(createElement(PropertyOwnerContactPanel, { title: "Maison à Divo", whatsappHref: "https://wa.me/2250712345678", ownerEmail: "proprietaire@example.ci" }));
    expect(html).toContain("Contacter par WhatsApp");
    expect(html).toContain("Écrire au propriétaire");
    expect(html).toContain("Préparer l’e-mail");
  });

  it("prépare le message demandé pour le contact WhatsApp de l’annonce", () => {
    const href = getPropertyOwnerContactHref("+2250712345678", "Maison à Divo");
    expect(href).toContain(encodeURIComponent("J'ai vu votre annonce sur le site E.G.K SARL et ça m'intéresse."));
  });
});
