import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import type { Request } from "express";
import { getSessionCookieOptions } from "./_core/cookies";

export const PROPERTY_OWNER_COOKIE_NAME = "egk_property_owner_session";
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;

function sessionSecret() {
  return process.env.JWT_SECRET || process.env.EGK_ADMIN_PASSWORD || "egk-property-owner-session";
}

function safeEqual(left: Buffer, right: Buffer) {
  return left.length === right.length && timingSafeEqual(left, right);
}

export function hashPropertyOwnerPassword(password: string) {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64);
  return `${salt.toString("hex")}.${hash.toString("hex")}`;
}

export function verifyPropertyOwnerPassword(password: string, storedHash: string) {
  const [saltHex, hashHex] = storedHash.split(".");
  if (!saltHex || !hashHex) return false;
  try {
    const expected = Buffer.from(hashHex, "hex");
    const actual = scryptSync(password, Buffer.from(saltHex, "hex"), expected.length);
    return safeEqual(actual, expected);
  } catch {
    return false;
  }
}

function sign(payload: string) {
  return createHmac("sha256", sessionSecret()).update(payload).digest("base64url");
}

export function createPropertyOwnerSession(ownerId: number) {
  const expiresAt = Date.now() + SESSION_TTL_MS;
  const payload = `${ownerId}.${expiresAt}`;
  return `${payload}.${sign(payload)}`;
}

function readCookie(req: Request) {
  const cookies = req.headers.cookie?.split(";") ?? [];
  const match = cookies.map(cookie => cookie.trim()).find(cookie => cookie.startsWith(`${PROPERTY_OWNER_COOKIE_NAME}=`));
  return match ? decodeURIComponent(match.slice(PROPERTY_OWNER_COOKIE_NAME.length + 1)) : undefined;
}

export function getPropertyOwnerId(req: Request) {
  const token = readCookie(req);
  if (!token) return null;
  const [ownerIdRaw, expiresAtRaw, signature] = token.split(".");
  const ownerId = Number(ownerIdRaw);
  const expiresAt = Number(expiresAtRaw);
  if (!Number.isSafeInteger(ownerId) || ownerId <= 0 || !Number.isSafeInteger(expiresAt) || expiresAt <= Date.now() || !signature) return null;
  const payload = `${ownerIdRaw}.${expiresAtRaw}`;
  return safeEqual(Buffer.from(signature), Buffer.from(sign(payload))) ? ownerId : null;
}

export function getPropertyOwnerCookieOptions(req: Request) {
  return {
    ...getSessionCookieOptions(req),
    maxAge: SESSION_TTL_MS,
  } as const;
}
