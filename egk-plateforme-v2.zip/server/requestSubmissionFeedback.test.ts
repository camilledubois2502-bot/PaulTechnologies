import { describe, expect, it } from "vitest";
import { requestSubmissionFeedback } from "../shared/requestSubmissionFeedback";

describe("requestSubmissionFeedback", () => {
  it("fournit un retour de succès et un état de chargement explicites", () => {
    expect(requestSubmissionFeedback.loadingLabel).toContain("Envoi");
    expect(requestSubmissionFeedback.successTitle).toContain("transmise");
    expect(requestSubmissionFeedback.successNextStep).toContain("Prochaine étape");
  });
});
