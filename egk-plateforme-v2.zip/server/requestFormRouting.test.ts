import { describe, expect, it } from "vitest";
import { getRequestFormContext, getRequestFormHref } from "../shared/requestFormRouting";

describe("requestFormRouting", () => {
  it("construit un lien vers le formulaire avec le type et la rubrique demandés", () => {
    expect(getRequestFormHref("finance", "finance")).toBe("/demander-un-service?type=finance&service=finance#formulaire-demande");
    expect(getRequestFormHref("general", "agriculture")).toBe("/demander-un-service?type=general&service=agriculture#formulaire-demande");
  });

  it("lit un contexte valide et retombe sur une demande générale si les paramètres sont invalides", () => {
    expect(getRequestFormContext("?type=reservation&service=gastronomie")).toEqual({ requestType: "reservation", serviceSlug: "gastronomie" });
    expect(getRequestFormContext("?type=invalide&service=<script>")).toEqual({ requestType: "general", serviceSlug: "general" });
  });
});
