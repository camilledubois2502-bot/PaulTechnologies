import { describe, expect, it } from "vitest";
import { filterManualTitleCatalogue } from "../client/src/lib/siteData";
import { normalizePropertyListingGallery } from "../shared/propertyListingGallery";
import { PROPERTY_MEDIA_MAX_FILES, PROPERTY_MEDIA_MIN_FILES, getPropertyMediaKind, isPropertyMediaMimeType } from "../shared/propertyMedia";

describe("recherche de manuels et médias immobiliers", () => {
  it("filtre les titres par recherche et niveau scolaire", () => {
    expect(filterManualTitleCatalogue("dictée", "all")).toHaveLength(3);
    expect(filterManualTitleCatalogue("", "Terminale").map(item => item.title)).toEqual(["Mémo Philo"]);
    expect(filterManualTitleCatalogue("maths", "Tous niveaux").map(item => item.title)).toEqual(["PRO DES MATHS — tous niveaux"]);
  });

  it("accepte les images et vidéos et limite le nombre de médias", () => {
    expect(isPropertyMediaMimeType("image/jpeg")).toBe(true);
    expect(isPropertyMediaMimeType("video/mp4")).toBe(true);
    expect(isPropertyMediaMimeType("application/pdf")).toBe(false);
    expect(getPropertyMediaKind("video/mp4")).toBe("video");
    expect(PROPERTY_MEDIA_MIN_FILES).toBe(4);
    expect(PROPERTY_MEDIA_MAX_FILES).toBe(8);
  });

  it("préserve les images et vidéos valides pour la galerie publiée", () => {
    expect(normalizePropertyListingGallery([
      { url: "/manus-storage/maison.jpg", type: "image", name: "Façade" },
      { url: "/manus-storage/visite.mp4", type: "video", name: "Visite" },
      { url: 42, type: "image" },
    ])).toEqual([
      { url: "/manus-storage/maison.jpg", type: "image", name: "Façade" },
      { url: "/manus-storage/visite.mp4", type: "video", name: "Visite" },
    ]);
  });
});
