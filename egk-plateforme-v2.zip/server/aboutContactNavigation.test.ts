import { describe, expect, it } from "vitest";
import { ADMINISTRATION_HREF, navigationItems } from "../client/src/lib/siteData";
import { TRAINING_ENROLLMENT_CONTACT_HREF } from "../shared/trainingContact";

describe("navigation À propos & Contact", () => {
  it("regroupe les accès publics et conserve l’inscription Formation dans la rubrique unique", () => {
    expect(navigationItems).toContainEqual({ label: "À propos & Contact", href: "/a-propos" });
    expect(navigationItems.some(item => item.label === "Contact" || item.href === "/contact")).toBe(false);
    expect(TRAINING_ENROLLMENT_CONTACT_HREF).toBe("/a-propos?objet=inscription-formation#formulaire-contact");
  });

  it("conserve un accès direct à l’espace Administration", () => {
    expect(ADMINISTRATION_HREF).toBe("/administration");
  });
});
