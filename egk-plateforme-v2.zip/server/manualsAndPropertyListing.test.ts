import { describe, expect, it } from "vitest";
import { manualTitleCatalogue, PROPERTY_LISTING_SERVICE_SLUG, propertyListingFields } from "../client/src/lib/siteData";

describe("bibliothèque et dépôt immobilier", () => {
  it("référence les titres de manuels communiqués", () => {
    expect(manualTitleCatalogue.map(manual => manual.title)).toEqual(expect.arrayContaining([
      "DICTÉE 6EME",
      "DICTÉE 5EME",
      "DICTÉE CP1 · CP2 · CM1 · CM2",
      "PRO DES MATHS — tous niveaux",
      "Mémo Philo",
      "Carnet de correspondance",
    ]));
  });

  it("prévoit les informations du propriétaire et du bien pour une annonce", () => {
    expect(PROPERTY_LISTING_SERVICE_SLUG).toBe("depot-annonce-immobiliere");
    expect(propertyListingFields.map(field => field.name)).toEqual(expect.arrayContaining(["proprietaire", "qualite", "typeBien", "adresseBien", "statut", "prix"]));
  });
});
