import { describe, expect, it } from "vitest";
import { trainingProgrammes } from "../client/src/lib/siteData";

describe("GK Formation programmes", () => {
  it("transcribes the ten programme names provided in the official poster", () => {
    expect(trainingProgrammes).toEqual([
      "Agropastoral",
      "Bilingue",
      "Esthétique",
      "Sanitaire Social",
      "Bâtiments",
      "BTP",
      "Communications AudioVisuelle",
      "Caissier/Caissière",
      "Informatiques",
      "Géomètre Topographe",
    ]);
  });
});

