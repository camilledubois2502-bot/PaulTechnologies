import { describe, expect, it } from "vitest";
import { matchesPropertyAvailability } from "../shared/propertyAvailabilityFilter";
import { getRealEstateNeedHref } from "../shared/realEstateNeeds";

describe("parcours immobilier et filtres", () => {
  it("redirige chaque besoin immobilier vers le formulaire contextualisé", () => {
    expect(getRealEstateNeedHref("Location de maisons")).toContain("type=rental&service=location-maisons");
    expect(getRealEstateNeedHref("Construction de maisons")).toContain("type=construction&service=construction-maison");
    expect(getRealEstateNeedHref("Professionnels partenaires")).toContain("type=btp_partner&service=professionnels-partenaires");
    expect(getRealEstateNeedHref("Modèles de maison")).toContain("type=construction&service=modeles-maison");
  });

  it("filtre les annonces par disponible, loué ou vendu", () => {
    expect(matchesPropertyAvailability({ availabilityStatus: "available" }, "available")).toBe(true);
    expect(matchesPropertyAvailability({ availabilityStatus: "rented" }, "available")).toBe(false);
    expect(matchesPropertyAvailability({ availabilityStatus: "sold" }, "sold")).toBe(true);
  });
});
