import { describe, expect, it } from "vitest";
import { assertPropertyListingIsReady, getPropertyListingSubmissionNotification, PROPERTY_LISTING_INITIAL_STATUS } from "../shared/propertyListingPublication";

describe("approbation des annonces immobilières", () => {
  it("place chaque annonce en attente après le dépôt propriétaire", () => {
    expect(PROPERTY_LISTING_INITIAL_STATUS).toBe("pending");
  });

  it("prépare une notification administrateur demandant une validation", () => {
    expect(getPropertyListingSubmissionNotification({
      fullName: "Awa Koné",
      location: "Divo",
      details: { typeBien: "Maison", adresseBien: "Quartier Grémian" },
    })).toEqual({
      title: "Nouvelle annonce immobilière à valider",
      content: "Awa Koné a soumis « Maison — Quartier Grémian ». Connectez-vous à l’administration E.G.K SARL pour l’approuver ou la refuser.",
    });
  });

  it("refuse le dépôt sans coordonnées et consentements propriétaires", () => {
    expect(() => assertPropertyListingIsReady({
      phone: "07 12 34 56 78",
      email: "proprietaire@example.ci",
      details: { contactDirectEnabled: "true", contactEmailEnabled: "false" },
    })).toThrow("Pour soumettre l’annonce");
  });

  it("refuse le dépôt avec moins de quatre médias", () => {
    expect(() => assertPropertyListingIsReady({
      phone: "07 12 34 56 78",
      email: "proprietaire@example.ci",
      details: { contactDirectEnabled: "true", contactEmailEnabled: "true", mediaGallery: JSON.stringify([{ url: "/1.jpg", type: "image" }]) },
    })).toThrow("au moins 4 médias");
  });
});
