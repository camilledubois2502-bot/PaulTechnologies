import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

vi.mock("./_core/notification", () => ({ notifyOwner: vi.fn() }));
vi.mock("./storage", () => ({ storageGetSignedUrl: vi.fn() }));

import { appRouter } from "./routers";

function createContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      cookie: vi.fn(),
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("adminSession.login", () => {
  beforeEach(() => {
    process.env.EGK_ADMIN_LOGIN = "EGKSARL";
    process.env.EGK_ADMIN_PASSWORD = "EGK2026SARL";
  });

  it("accepte les identifiants administrateur fournis via l’API légère", async () => {
    const context = createContext();
    const caller = appRouter.createCaller(context);

    const result = await caller.adminSession.login({
      login: "EGKSARL",
      password: "EGK2026SARL",
    });

    expect(result).toEqual({ success: true });
    expect(context.res.cookie).toHaveBeenCalledWith(
      "egk_admin_session",
      expect.any(String),
      expect.objectContaining({ httpOnly: true, secure: true }),
    );
  });

  it("refuse un mot de passe incorrect", async () => {
    const caller = appRouter.createCaller(createContext());

    await expect(caller.adminSession.login({
      login: "EGKSARL",
      password: "mauvais-mot-de-passe",
    })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
