import { describe, expect, it } from "vitest";
import { catalogItemInputSchema, contentItemInputSchema } from "./adminSchemas";

describe("administration input schemas", () => {
  it("accepts a publishable content entry with a clean slug", () => {
    expect(contentItemInputSchema.parse({
      contentType: "actualite",
      sector: "formation",
      slug: "inscriptions-2026",
      title: "Inscriptions 2026",
      isPublished: true,
    }).slug).toBe("inscriptions-2026");
  });

  it("rejects a catalogue slug that cannot form a clean public URL", () => {
    expect(catalogItemInputSchema.safeParse({
      kind: "property",
      sector: "immobilier-btp",
      slug: "Maison Divo !",
      title: "Maison à Divo",
    }).success).toBe(false);
  });
});

