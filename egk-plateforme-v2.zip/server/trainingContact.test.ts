import { describe, expect, it } from "vitest";
import { isTrainingEnrollmentContactSearch, TRAINING_EDUCATION_LEVELS, TRAINING_ENROLLMENT_CONTACT_HREF, TRAINING_ENROLLMENT_SUBJECT } from "../shared/trainingContact";
import { trainingProgrammes } from "../client/src/lib/siteData";

describe("parcours d’inscription GK Formation", () => {
  it("redirectionne vers le formulaire de la rubrique À propos & Contact avec le paramètre d’inscription", () => {
    expect(TRAINING_ENROLLMENT_CONTACT_HREF).toBe("/a-propos?objet=inscription-formation#formulaire-contact");
    expect(isTrainingEnrollmentContactSearch("?objet=inscription-formation")).toBe(true);
  });

  it("prépare un objet explicite pour la demande d’inscription", () => {
    expect(TRAINING_ENROLLMENT_SUBJECT).toBe("Demande d’inscription — GK Formation");
    expect(isTrainingEnrollmentContactSearch("?objet=contact")).toBe(false);
  });

  it("propose les filières officielles et les niveaux d’étude actuels", () => {
    expect(trainingProgrammes).toContain("Géomètre Topographe");
    expect(TRAINING_EDUCATION_LEVELS).toEqual(expect.arrayContaining(["Primaire", "Baccalauréat", "Enseignement supérieur"]));
  });
});
