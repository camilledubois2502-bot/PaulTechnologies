import { describe, expect, it } from "vitest";
import { ADMINISTRATION_HREF, PUBLIC_NAVIGATION_MODE } from "../client/src/lib/siteData";

describe("navigation publique E.G.K SARL", () => {
  it("utilise uniquement le menu supérieur pour les changements de page", () => {
    expect(PUBLIC_NAVIGATION_MODE).toBe("menu-only");
    expect(ADMINISTRATION_HREF).toBe("/administration");
  });
});
