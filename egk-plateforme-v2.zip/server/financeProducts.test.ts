import { describe, expect, it } from "vitest";
import { financeProducts } from "../client/src/lib/siteData";

describe("produits Finance EGK", () => {
  it("expose les trois produits transcrits depuis le support fourni", () => {
    expect(financeProducts.map(product => product.title)).toEqual([
      "Extension Business",
      "Paie mon École",
      "Vacances Libres",
    ]);
  });

  it("préserve les trois montants mensuels de l’offre Vacances Libres", () => {
    expect(financeProducts[2].details).toEqual(expect.arrayContaining([
      "Épargnez selon l’aide souhaitée pendant trois mois de vacances : juin, juillet et août.",
      "Offre Soulagement : 50 000 F / mois pendant 3 mois.",
      "Offre Providence : 60 000 F / mois pendant 3 mois.",
      "Offre Satisfaction : 75 000 F / mois pendant 3 mois.",
      "Le préalable pour bénéficier de tous ces produits est d’avoir un compte ouvert dans notre service Micro Crédit et Solidarité.",
    ]));
  });

  it("préserve les modalités confirmées d’Extension Business et Paie mon École", () => {
    expect(financeProducts[0].title).toBe("Extension Business");
    expect(financeProducts[0].details).toContain("Montant disponible : 50 000 F à 200 000 F CFA selon votre activité et votre capacité de remboursement.");
    expect(financeProducts[1].details).toContain("Vous ne payez que l’inscription en ligne et les frais annexes.");
  });
});
