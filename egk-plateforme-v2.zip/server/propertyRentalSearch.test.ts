import { describe, expect, it } from "vitest";
import { isPublishedAvailableRental, isRentalListingType, matchesPropertyRentalCriteria } from "../shared/propertyRentalSearch";

describe("recherche locative immobilière", () => {
  const rental = { region: "Gôh-Djiboua", city: "Divo", housingType: "Maison de 3 chambres", monthlyRent: 85000 };

  it("retient un logement correspondant à la région, la ville, le type et le budget", () => {
    expect(matchesPropertyRentalCriteria(rental, {
      region: "gôh",
      city: "divo",
      housingType: "maison",
      maxMonthlyRent: "100000",
    })).toBe(true);
  });

  it("écarte un logement dont le loyer dépasse le budget maximal", () => {
    expect(matchesPropertyRentalCriteria(rental, {
      region: "",
      city: "",
      housingType: "",
      maxMonthlyRent: "80000",
    })).toBe(false);
  });

  it("écarte une annonce sans loyer renseigné lorsqu’un budget est demandé", () => {
    expect(matchesPropertyRentalCriteria({ region: "Gôh-Djiboua", city: "Divo", housingType: "Appartement", monthlyRent: null }, {
      region: "",
      city: "",
      housingType: "",
      maxMonthlyRent: "100000",
    })).toBe(false);
  });

  it("réserve la recherche locative aux annonces publiées, disponibles et de type location", () => {
    expect(isPublishedAvailableRental({ ...rental, isPublishedListing: true, isRentalListing: true, availabilityStatus: "available" })).toBe(true);
    expect(isPublishedAvailableRental({ ...rental, isPublishedListing: false, isRentalListing: true, availabilityStatus: "available" })).toBe(false);
    expect(isPublishedAvailableRental({ ...rental, isPublishedListing: true, isRentalListing: false, availabilityStatus: "available" })).toBe(false);
    expect(isRentalListingType("Location")).toBe(true);
    expect(isRentalListingType("Vente")).toBe(false);
  });
});
