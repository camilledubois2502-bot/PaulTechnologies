import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  createServiceRequest: vi.fn(),
  notifyOwner: vi.fn(),
}));

vi.mock("./db", () => ({
  createCatalogItem: vi.fn(),
  createContentItem: vi.fn(),
  createManualDocument: vi.fn(),
  createMediaItem: vi.fn(),
  createPropertyOwner: vi.fn(),
  createServiceRequest: mocks.createServiceRequest,
  getAdminStats: vi.fn(),
  getManualDocumentById: vi.fn(),
  getPropertyOwnerByEmail: vi.fn(),
  getPropertyOwnerById: vi.fn(),
  listAdminCatalog: vi.fn(),
  listAdminContent: vi.fn(),
  listAdminManualDocuments: vi.fn(),
  listAdminMedia: vi.fn(),
  listPublishedManualDocuments: vi.fn(),
  listServiceRequests: vi.fn(),
}));

vi.mock("./_core/notification", () => ({ notifyOwner: mocks.notifyOwner }));
vi.mock("./storage", () => ({ storageGetSignedUrl: vi.fn() }));

import { appRouter } from "./routers";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("serviceRequests.create", () => {
  beforeEach(() => {
    mocks.createServiceRequest.mockReset();
    mocks.notifyOwner.mockReset();
    mocks.createServiceRequest.mockResolvedValue({ id: 42, receivedAt: new Date("2026-08-23T00:00:00Z") });
    mocks.notifyOwner.mockResolvedValue(true);
  });

  it("records a valid public request and notifies the project owner", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const request = {
      requestType: "construction" as const,
      serviceSlug: "construction-maison",
      fullName: "Awa Koné",
      phone: "+225 07 00 00 00 00",
      email: "awa@example.ci",
      location: "Divo",
      subject: "Projet de maison",
      message: "Je souhaite étudier les possibilités d’accompagnement pour construire ma maison.",
      details: { chambres: "3" },
    };

    const result = await caller.serviceRequests.create(request);

    expect(mocks.createServiceRequest).toHaveBeenCalledWith(request);
    expect(mocks.notifyOwner).toHaveBeenCalledWith(expect.objectContaining({ title: "Nouvelle demande EGK" }));
    expect(result).toMatchObject({ id: 42, notificationSent: true });
  });

  it("refuse le dépôt immobilier anonyme afin d’imposer le compte propriétaire", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const request = {
      requestType: "general" as const,
      serviceSlug: "depot-annonce-immobiliere",
      fullName: "Awa Koné",
      phone: "+225 07 00 00 00 00",
      email: "awa@example.ci",
      location: "Divo",
      subject: "",
      message: "Je publie une annonce complète pour une maison familiale à Divo.",
      details: {
        proprietaire: "Awa Koné",
        typeBien: "Maison",
        adresseBien: "Quartier Grémian",
        contactDirectEnabled: "true",
        contactEmailEnabled: "true",
      },
    };

    await expect(caller.serviceRequests.create(request)).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mocks.createServiceRequest).not.toHaveBeenCalled();
    expect(mocks.notifyOwner).not.toHaveBeenCalled();
  });
});
