import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { ADMIN_COOKIE_NAME, createAdminSession, getAdminCookieOptions, isAdminCredential, isAdminSession } from "./adminAuth";
import { createCatalogItem, createContentItem, createManualDocument, createMediaItem, createPropertyOwner, createServiceRequest, getAdminStats, getManualDocumentById, getPropertyOwnerByEmail, getPropertyOwnerById, listAdminCatalog, listAdminContent, listAdminManualDocuments, listAdminMedia, listPropertyListingsForReview, listPublishedManualDocuments, listPublishedPropertyListings, listServiceRequests, reviewPropertyListing } from "./db";
import { catalogItemInputSchema, contentItemInputSchema, manualDocumentInputSchema, mediaItemInputSchema } from "./adminSchemas";
import { requestTypeValues, serviceRequestInputSchema } from "./requestSchemas";
import { getSessionCookieOptions } from "./_core/cookies";
import { notifyOwner } from "./_core/notification";
import { storageGetSignedUrl } from "./storage";
import { getImmediatePropertyListingOwnerNotification } from "../shared/propertyListingPublication";
import { createPropertyOwnerSession, getPropertyOwnerCookieOptions, getPropertyOwnerId, hashPropertyOwnerPassword, PROPERTY_OWNER_COOKIE_NAME, verifyPropertyOwnerPassword } from "./propertyOwnerAuth";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const staffRoles = ["admin", "content_manager", "training_manager", "real_estate_manager"] as const;

const staffProcedure = publicProcedure.use(({ ctx, next }) => {
  const isStaff = Boolean(ctx.user && staffRoles.includes(ctx.user.role as (typeof staffRoles)[number]));
  if (!isStaff && !isAdminSession(ctx.req)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Accès réservé à l’administration EGK." });
  }
  return next();
});

const propertyManagerProcedure = publicProcedure.use(({ ctx, next }) => {
  const isPropertyManager = Boolean(ctx.user && (["admin", "real_estate_manager"] as const).includes(ctx.user.role as "admin" | "real_estate_manager"));
  if (!isPropertyManager && !isAdminSession(ctx.req)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Accès réservé à la gestion immobilière EGK." });
  }
  return next();
});

const propertyOwnerProcedure = publicProcedure.use(({ ctx, next }) => {
  const propertyOwnerId = getPropertyOwnerId(ctx.req);
  if (!propertyOwnerId) throw new TRPCError({ code: "UNAUTHORIZED", message: "Connectez-vous comme propriétaire pour déposer une annonce." });
  return next({ ctx: { ...ctx, propertyOwnerId } });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  adminSession: router({
    login: publicProcedure.input(z.object({ login: z.string().trim().min(1).max(120), password: z.string().min(1).max(200) })).mutation(({ ctx, input }) => {
      if (!isAdminCredential(input.login, input.password)) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Identifiants administrateur invalides." });
      }
      ctx.res.cookie(ADMIN_COOKIE_NAME, createAdminSession(input.login), getAdminCookieOptions(ctx.req));
      return { success: true } as const;
    }),
    me: publicProcedure.query(({ ctx }) => ({ authenticated: isAdminSession(ctx.req) })),
    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(ADMIN_COOKIE_NAME, { ...getAdminCookieOptions(ctx.req), maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  propertyOwner: router({
    register: publicProcedure.input(z.object({
      fullName: z.string().trim().min(2).max(180),
      phone: z.string().trim().min(6).max(40),
      email: z.string().trim().email().max(320),
      password: z.string().min(8).max(200),
    })).mutation(async ({ ctx, input }) => {
      const email = input.email.toLowerCase();
      if (await getPropertyOwnerByEmail(email)) throw new TRPCError({ code: "CONFLICT", message: "Un compte propriétaire existe déjà avec cet e-mail." });
      const owner = await createPropertyOwner({ ...input, email, passwordHash: hashPropertyOwnerPassword(input.password) });
      if (!owner) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Le compte propriétaire n’a pas pu être créé." });
      ctx.res.cookie(PROPERTY_OWNER_COOKIE_NAME, createPropertyOwnerSession(owner.id), getPropertyOwnerCookieOptions(ctx.req));
      return { id: owner.id, fullName: owner.fullName, email: owner.email };
    }),
    login: publicProcedure.input(z.object({ email: z.string().trim().email(), password: z.string().min(1).max(200) })).mutation(async ({ ctx, input }) => {
      const owner = await getPropertyOwnerByEmail(input.email);
      if (!owner || !verifyPropertyOwnerPassword(input.password, owner.passwordHash)) throw new TRPCError({ code: "UNAUTHORIZED", message: "E-mail ou mot de passe propriétaire incorrect." });
      ctx.res.cookie(PROPERTY_OWNER_COOKIE_NAME, createPropertyOwnerSession(owner.id), getPropertyOwnerCookieOptions(ctx.req));
      return { id: owner.id, fullName: owner.fullName, email: owner.email };
    }),
    me: publicProcedure.query(async ({ ctx }) => {
      const ownerId = getPropertyOwnerId(ctx.req);
      if (!ownerId) return null;
      const owner = await getPropertyOwnerById(ownerId);
      return owner ? { id: owner.id, fullName: owner.fullName, phone: owner.phone, email: owner.email } : null;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(PROPERTY_OWNER_COOKIE_NAME, { ...getPropertyOwnerCookieOptions(ctx.req), maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  serviceRequests: router({
    create: publicProcedure.input(serviceRequestInputSchema).mutation(async ({ input }) => {
      if (input.serviceSlug === "depot-annonce-immobiliere") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Inscrivez-vous ou connectez-vous comme propriétaire pour déposer une annonce." });
      }
      const request = await createServiceRequest(input);
      const notification = {
        title: "Nouvelle demande EGK",
        content: `Une demande « ${input.requestType} » a été déposée par ${input.fullName}. Consultez l’administration EGK pour la traiter.`,
      };
      const notificationSent = await notifyOwner({
        ...notification,
      }).catch(() => false);
      return { ...request, notificationSent };
    }),
    list: staffProcedure.query(() => listServiceRequests()),
    metadata: publicProcedure.query(() => ({ requestTypes: requestTypeValues })),
  }),
  propertyListings: router({
    listPublished: publicProcedure.query(() => listPublishedPropertyListings()),
    listForReview: propertyManagerProcedure.query(() => listPropertyListingsForReview()),
    review: propertyManagerProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["published", "rejected"]) })).mutation(({ input }) => reviewPropertyListing(input.id, input.status)),
    create: propertyOwnerProcedure.input(serviceRequestInputSchema).mutation(async ({ ctx, input }) => {
      if (input.serviceSlug !== "depot-annonce-immobiliere") throw new TRPCError({ code: "BAD_REQUEST", message: "Le dépôt concerne uniquement une annonce immobilière." });
      const request = await createServiceRequest(input, ctx.propertyOwnerId);
      const notificationSent = await notifyOwner(getImmediatePropertyListingOwnerNotification(input)).catch(() => false);
      return { ...request, notificationSent, status: "pending" as const };
    }),
  }),
  admin: router({
    stats: staffProcedure.query(() => getAdminStats()),
    content: staffProcedure.query(() => listAdminContent()),
    createContent: staffProcedure.input(contentItemInputSchema).mutation(({ input }) => createContentItem(input)),
    catalog: staffProcedure.query(() => listAdminCatalog()),
    createCatalogItem: staffProcedure.input(catalogItemInputSchema).mutation(({ input }) => createCatalogItem(input)),
    media: staffProcedure.query(() => listAdminMedia()),
    createMediaItem: staffProcedure.input(mediaItemInputSchema).mutation(({ input }) => createMediaItem(input)),
    manuals: staffProcedure.query(() => listAdminManualDocuments()),
    createManual: staffProcedure.input(manualDocumentInputSchema).mutation(({ input }) => createManualDocument(input)),
  }),
  manuals: router({
    list: publicProcedure.query(() => listPublishedManualDocuments()),
    open: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      if (!["student", "training_manager", "admin"].includes(ctx.user.role)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Votre rôle ne permet pas la consultation de cette ressource." });
      }
      const document = await getManualDocumentById(input.id);
      if (!document || !document.isPublished) throw new TRPCError({ code: "NOT_FOUND", message: "Manuel introuvable." });
      const url = await storageGetSignedUrl(document.fileKey);
      return { title: document.title, url };
    }),
  }),
});

export type AppRouter = typeof appRouter;
