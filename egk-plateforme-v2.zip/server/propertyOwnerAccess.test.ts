import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
import { createPropertyOwnerSession, hashPropertyOwnerPassword } from "./propertyOwnerAuth";

const mocks = vi.hoisted(() => ({
  createPropertyOwner: vi.fn(),
  createServiceRequest: vi.fn(),
  getPropertyOwnerByEmail: vi.fn(),
  getPropertyOwnerById: vi.fn(),
  notifyOwner: vi.fn(),
}));

vi.mock("./db", () => ({
  createCatalogItem: vi.fn(), createContentItem: vi.fn(), createManualDocument: vi.fn(), createMediaItem: vi.fn(),
  createPropertyOwner: mocks.createPropertyOwner, createServiceRequest: mocks.createServiceRequest,
  getAdminStats: vi.fn(), getManualDocumentById: vi.fn(), getPropertyOwnerByEmail: mocks.getPropertyOwnerByEmail,
  getPropertyOwnerById: mocks.getPropertyOwnerById, listAdminCatalog: vi.fn(), listAdminContent: vi.fn(),
  listAdminManualDocuments: vi.fn(), listAdminMedia: vi.fn(), listPropertyListingsForReview: vi.fn(),
  listPublishedManualDocuments: vi.fn(), listPublishedPropertyListings: vi.fn(), listServiceRequests: vi.fn(),
  reviewPropertyListing: vi.fn(),
}));
vi.mock("./_core/notification", () => ({ notifyOwner: mocks.notifyOwner }));
vi.mock("./storage", () => ({ storageGetSignedUrl: vi.fn() }));

import { appRouter } from "./routers";

function createContext(cookie = ""): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: cookie ? { cookie } : {} } as TrpcContext["req"],
    res: { cookie: vi.fn(), clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const owner = { id: 7, fullName: "Awa Koné", phone: "+2250700000000", email: "awa@example.ci", passwordHash: hashPropertyOwnerPassword("motdepasse123") };

const listingRequest = {
  requestType: "general" as const,
  serviceSlug: "depot-annonce-immobiliere",
  fullName: "Awa Koné",
  phone: "+2250700000000",
  email: "awa@example.ci",
  location: "Divo",
  subject: "",
  message: "Maison familiale disponible à la location dans le quartier Grémian.",
  details: { proprietaire: "Awa Koné", typeBien: "Maison", adresseBien: "Quartier Grémian", contactDirectEnabled: "true", contactEmailEnabled: "true", mediaGallery: JSON.stringify([
    { url: "/media/1.jpg", type: "image", name: "Façade" },
    { url: "/media/2.jpg", type: "image", name: "Salon" },
    { url: "/media/3.jpg", type: "image", name: "Chambre" },
    { url: "/media/4.mp4", type: "video", name: "Visite" },
  ]) },
};

describe("accès propriétaires immobiliers", () => {
  it("inscrit un propriétaire et ouvre sa session", async () => {
    mocks.getPropertyOwnerByEmail.mockResolvedValueOnce(undefined);
    mocks.createPropertyOwner.mockResolvedValueOnce(owner);
    const context = createContext();
    const result = await appRouter.createCaller(context).propertyOwner.register({ fullName: owner.fullName, phone: owner.phone, email: owner.email, password: "motdepasse123" });
    expect(result).toEqual({ id: 7, fullName: "Awa Koné", email: "awa@example.ci" });
    expect(context.res.cookie).toHaveBeenCalledWith("egk_property_owner_session", expect.any(String), expect.objectContaining({ httpOnly: true, secure: true }));
  });

  it("connecte un propriétaire avec son mot de passe", async () => {
    mocks.getPropertyOwnerByEmail.mockResolvedValueOnce(owner);
    const context = createContext();
    const result = await appRouter.createCaller(context).propertyOwner.login({ email: owner.email, password: "motdepasse123" });
    expect(result).toMatchObject({ id: 7, email: owner.email });
    expect(context.res.cookie).toHaveBeenCalled();
  });

  it("autorise le dépôt seulement avec une session propriétaire", async () => {
    mocks.createServiceRequest.mockResolvedValueOnce({ id: 99, propertyListingId: 12, receivedAt: new Date() });
    mocks.notifyOwner.mockResolvedValueOnce(true);
    const cookie = `egk_property_owner_session=${createPropertyOwnerSession(owner.id)}`;
    const result = await appRouter.createCaller(createContext(cookie)).propertyListings.create(listingRequest);
    expect(mocks.createServiceRequest).toHaveBeenCalledWith(listingRequest, owner.id);
    expect(result).toMatchObject({ id: 99, propertyListingId: 12, status: "pending", notificationSent: true });
  });
});
