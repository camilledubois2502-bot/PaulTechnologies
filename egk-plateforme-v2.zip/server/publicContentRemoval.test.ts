import { describe, expect, it } from "vitest";
import { catalogItems, navigationItems, sectors } from "../client/src/lib/siteData";

describe("contenus publics retirés", () => {
  it("n’expose plus les contenus retirés de l’interface publique", () => {
    const publicContent = JSON.stringify({ navigationItems, sectors, catalogItems });
    const removedNewsLabel = ["Actualit", "és"].join("");
    const removedHousingLabel = ["Projet", "FAD"].join(" ");

    expect(navigationItems.some(item => item.href === "/actualites")).toBe(false);
    expect(publicContent).not.toContain(removedNewsLabel);
    expect(publicContent).not.toContain(removedHousingLabel);
  });
});
