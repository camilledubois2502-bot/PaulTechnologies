import { describe, expect, it } from "vitest";
import { getWhatsAppHref, getWhatsAppMessage } from "../shared/whatsapp";

describe("contextual WhatsApp message", () => {
  it("adapts the message to the active sector", () => {
    expect(getWhatsAppMessage("/immobilier-btp")).toContain("l’immobilier et BTP");
    expect(getWhatsAppHref("/immobilier-btp")).toContain("wa.me/2250564354390?text=");
  });

  it("uses EGK services as a safe fallback on generic routes", () => {
    expect(getWhatsAppMessage("/contact")).toContain("les services EGK");
  });
});
