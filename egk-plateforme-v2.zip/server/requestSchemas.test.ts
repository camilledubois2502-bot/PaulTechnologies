import { describe, expect, it } from "vitest";
import { serviceRequestInputSchema } from "./requestSchemas";

describe("serviceRequestInputSchema", () => {
  const validRequest = {
    requestType: "construction" as const,
    serviceSlug: "construction-maison",
    fullName: "Awa Koné",
    phone: "+225 07 00 00 00 00",
    email: "awa@example.ci",
    location: "Divo",
    subject: "Projet de maison",
    message: "Je souhaite être accompagnée pour étudier mon projet de construction.",
    details: { chambres: "3" },
  };

  it("accepts a complete service request", () => {
    expect(serviceRequestInputSchema.parse(validRequest)).toMatchObject({
      requestType: "construction",
      serviceSlug: "construction-maison",
    });
  });

  it("rejects a request without a usable contact or sufficient message", () => {
    const result = serviceRequestInputSchema.safeParse({
      ...validRequest,
      phone: "123",
      message: "Besoin",
    });
    expect(result.success).toBe(false);
  });
});

