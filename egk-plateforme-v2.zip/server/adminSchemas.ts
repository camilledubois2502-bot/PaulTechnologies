import { z } from "zod";

const slugSchema = z.string().trim().min(3).max(160).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Utilisez des minuscules, chiffres et tirets.");

export const contentItemInputSchema = z.object({
  contentType: z.string().trim().min(2).max(64),
  sector: z.string().trim().min(2).max(64),
  slug: slugSchema,
  title: z.string().trim().min(3).max(240),
  summary: z.string().trim().max(2000).optional(),
  body: z.string().trim().max(12000).optional(),
  imageUrl: z.union([z.string().trim().regex(/^(https?:\/\/|\/manus-storage\/)/), z.literal("")]).optional(),
  isPublished: z.boolean().default(false),
});

export const catalogItemInputSchema = z.object({
  kind: z.enum(["property", "agriculture", "livestock", "transport", "manual"]),
  sector: z.string().trim().min(2).max(64),
  slug: slugSchema,
  title: z.string().trim().min(3).max(240),
  description: z.string().trim().max(4000).optional(),
  imageUrl: z.union([z.string().trim().regex(/^(https?:\/\/|\/manus-storage\/)/), z.literal("")]).optional(),
  location: z.string().trim().max(160).optional(),
  priceLabel: z.string().trim().max(160).optional(),
  availabilityLabel: z.string().trim().max(160).optional(),
  isPublished: z.boolean().default(false),
});

export const mediaItemInputSchema = z.object({
  category: z.string().trim().min(2).max(64),
  title: z.string().trim().min(3).max(240),
  altText: z.string().trim().max(320).optional(),
  fileUrl: z.string().trim().regex(/^(https?:\/\/|\/manus-storage\/)/, "Utilisez une URL https ou un chemin /manus-storage/."),
  mediaType: z.enum(["image", "video", "document"]),
  isPublished: z.boolean().default(false),
});

export const manualDocumentInputSchema = z.object({
  slug: slugSchema,
  title: z.string().trim().min(3).max(240),
  category: z.string().trim().min(2).max(96),
  level: z.string().trim().max(96).optional(),
  description: z.string().trim().max(4000).optional(),
  fileKey: z.string().trim().min(5).max(500).transform(value => value.replace(/^\/manus-storage\//, "")),
  isPublished: z.boolean().default(false),
});
