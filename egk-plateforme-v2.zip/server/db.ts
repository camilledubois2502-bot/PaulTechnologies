import { count, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, PropertyListing, PropertyOwner, ServiceRequest, catalogItems, contentItems, manualDocuments, mediaItems, propertyListings, propertyOwners, serviceRequests, users } from "../drizzle/schema";
import type { z } from "zod";
import type { catalogItemInputSchema, contentItemInputSchema, manualDocumentInputSchema, mediaItemInputSchema } from "./adminSchemas";
import type { ServiceRequestInput } from "./requestSchemas";
import { ENV } from "./_core/env";
import { normalizePropertyListingGallery } from "../shared/propertyListingGallery";
import { canPublishPropertyListing } from "../shared/propertyListingContact";
import { assertPropertyListingIsReady, PROPERTY_LISTING_INITIAL_STATUS } from "../shared/propertyListingPublication";
import { isRentalListingType } from "../shared/propertyRentalSearch";

function parseMonthlyRent(value?: string) {
  const parsed = Number(String(value ?? "").replace(/\D/g, ""));
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : null;
}

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach(field => {
    if (user[field] !== undefined) {
      const value = user[field] ?? null;
      values[field] = value;
      updateSet[field] = value;
    }
  });

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getPropertyOwnerByEmail(email: string): Promise<PropertyOwner | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  return (await db.select().from(propertyOwners).where(eq(propertyOwners.email, email.toLowerCase())).limit(1))[0];
}

export async function getPropertyOwnerById(id: number): Promise<PropertyOwner | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  return (await db.select().from(propertyOwners).where(eq(propertyOwners.id, id)).limit(1))[0];
}

export async function createPropertyOwner(input: { fullName: string; phone: string; email: string; passwordHash: string }) {
  const db = await getDb();
  if (!db) throw new Error("Le service d’inscription est momentanément indisponible.");
  const result = await db.insert(propertyOwners).values({ ...input, email: input.email.toLowerCase() });
  return getPropertyOwnerById(Number(result[0].insertId));
}

export async function createServiceRequest(input: ServiceRequestInput, ownerAccountId?: number) {
  const db = await getDb();
  if (!db) throw new Error("Le service de réception des demandes est momentanément indisponible.");

  const propertyListingDetails = input.serviceSlug === "depot-annonce-immobiliere" ? input.details ?? {} : null;
  if (propertyListingDetails) assertPropertyListingIsReady({ phone: input.phone, email: input.email, details: propertyListingDetails });
  if (propertyListingDetails && isRentalListingType(propertyListingDetails.statut) && !parseMonthlyRent(propertyListingDetails.loyerMensuel)) {
    throw new Error("Renseignez un loyer mensuel chiffré pour publier une annonce de location.");
  }

  const values = {
    requestType: input.requestType,
    serviceSlug: input.serviceSlug,
    fullName: input.fullName,
    phone: input.phone,
    email: input.email || null,
    location: input.location || null,
    subject: input.subject || null,
    message: input.message,
    details: input.details ?? null,
  } as const;

  const result = await db.insert(serviceRequests).values(values);
  const requestId = Number(result[0].insertId);

  if (input.serviceSlug === "depot-annonce-immobiliere") {
    const details = propertyListingDetails ?? {};
    const parsedGallery = (() => {
      try {
        return normalizePropertyListingGallery(JSON.parse(details.mediaGallery ?? "[]"));
      } catch {
        return [];
      }
    })();
    const propertyType = details.typeBien || "Bien immobilier";
    const listingLocation = details.adresseBien || input.location || "Localisation à confirmer";
    const monthlyRent = parseMonthlyRent(details.loyerMensuel);
    const listingResult = await db.insert(propertyListings).values({
      submissionRequestId: requestId,
      ownerAccountId: ownerAccountId ?? null,
      ownerName: details.proprietaire || input.fullName,
      ownerRole: details.qualite || null,
      title: `${propertyType} — ${listingLocation}`.slice(0, 240),
      listingType: details.statut || "Annonce immobilière",
      location: listingLocation,
      region: details.regionBien || null,
      city: details.villeBien || null,
      housingType: propertyType,
      monthlyRent,
      priceLabel: monthlyRent ? `${monthlyRent.toLocaleString("fr-FR")} FCFA / mois` : details.prix || null,
      configuration: details.chambres || null,
      surface: details.surface || null,
      description: input.message,
      contactPhone: input.phone,
      contactEmail: input.email || null,
      contactDirectEnabled: details.contactDirectEnabled === "true",
      contactEmailEnabled: details.contactEmailEnabled === "true",
      availabilityStatus: details.availabilityStatus === "rented" || details.availabilityStatus === "sold" ? details.availabilityStatus : "available",
      gallery: parsedGallery,
      status: PROPERTY_LISTING_INITIAL_STATUS,
    });
    return { id: requestId, propertyListingId: Number(listingResult[0].insertId), receivedAt: new Date() };
  }

  return { id: requestId, receivedAt: new Date() };
}

export async function listServiceRequests(limit = 30): Promise<ServiceRequest[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(serviceRequests)
    .orderBy(desc(serviceRequests.createdAt))
    .limit(Math.min(Math.max(limit, 1), 100));
}

export async function listPublishedPropertyListings(): Promise<PropertyListing[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(propertyListings).where(eq(propertyListings.status, "published")).orderBy(desc(propertyListings.updatedAt)).limit(100);
}

export async function listPropertyListingsForReview(): Promise<PropertyListing[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(propertyListings).orderBy(desc(propertyListings.createdAt)).limit(100);
}

export async function reviewPropertyListing(id: number, status: "published" | "rejected") {
  const db = await getDb();
  if (!db) throw new Error("Le service d’annonces est momentanément indisponible.");
  const listing = (await db.select().from(propertyListings).where(eq(propertyListings.id, id)).limit(1))[0];
  if (!listing) throw new Error("Annonce immobilière introuvable.");
  if (status === "published" && !canPublishPropertyListing(listing.contactPhone, listing.contactEmail, listing.contactDirectEnabled, listing.contactEmailEnabled)) {
    throw new Error("Cette annonce doit comporter les consentements WhatsApp et e-mail ainsi que les coordonnées du propriétaire avant publication.");
  }
  await db.update(propertyListings).set({ status }).where(eq(propertyListings.id, id));
  return { id, status };
}

type ContentInput = z.infer<typeof contentItemInputSchema>;
type CatalogInput = z.infer<typeof catalogItemInputSchema>;
type MediaInput = z.infer<typeof mediaItemInputSchema>;
type ManualInput = z.infer<typeof manualDocumentInputSchema>;

export async function listAdminContent() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contentItems).orderBy(desc(contentItems.updatedAt)).limit(100);
}

export async function createContentItem(input: ContentInput) {
  const db = await getDb();
  if (!db) throw new Error("Le service de contenu est momentanément indisponible.");
  const result = await db.insert(contentItems).values({
    ...input,
    summary: input.summary || null,
    body: input.body || null,
    imageUrl: input.imageUrl || null,
    publishedAt: input.isPublished ? new Date() : null,
  });
  return { id: Number(result[0].insertId) };
}

export async function listAdminCatalog() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(catalogItems).orderBy(desc(catalogItems.updatedAt)).limit(100);
}

export async function createCatalogItem(input: CatalogInput) {
  const db = await getDb();
  if (!db) throw new Error("Le service de catalogue est momentanément indisponible.");
  const result = await db.insert(catalogItems).values({
    ...input,
    description: input.description || null,
    imageUrl: input.imageUrl || null,
    location: input.location || null,
    priceLabel: input.priceLabel || null,
    availabilityLabel: input.availabilityLabel || null,
  });
  return { id: Number(result[0].insertId) };
}

export async function listAdminMedia() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(mediaItems).orderBy(desc(mediaItems.updatedAt)).limit(100);
}

export async function createMediaItem(input: MediaInput) {
  const db = await getDb();
  if (!db) throw new Error("Le service de médias est momentanément indisponible.");
  const result = await db.insert(mediaItems).values({
    ...input,
    altText: input.altText || null,
  });
  return { id: Number(result[0].insertId) };
}

export async function getAdminStats() {
  const db = await getDb();
  if (!db) return { requests: 0, content: 0, catalog: 0, media: 0 };
  const [[requests], [content], [catalog], [media]] = await Promise.all([
    db.select({ total: count() }).from(serviceRequests),
    db.select({ total: count() }).from(contentItems),
    db.select({ total: count() }).from(catalogItems),
    db.select({ total: count() }).from(mediaItems),
  ]);
  return {
    requests: Number(requests?.total ?? 0),
    content: Number(content?.total ?? 0),
    catalog: Number(catalog?.total ?? 0),
    media: Number(media?.total ?? 0),
  };
}

export async function listAdminManualDocuments() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(manualDocuments).orderBy(desc(manualDocuments.updatedAt)).limit(100);
}

export async function listPublishedManualDocuments() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ id: manualDocuments.id, slug: manualDocuments.slug, title: manualDocuments.title, category: manualDocuments.category, level: manualDocuments.level, description: manualDocuments.description })
    .from(manualDocuments)
    .where(eq(manualDocuments.isPublished, true))
    .orderBy(desc(manualDocuments.updatedAt));
}

export async function getManualDocumentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(manualDocuments).where(eq(manualDocuments.id, id)).limit(1);
  return result[0];
}

export async function createManualDocument(input: ManualInput) {
  const db = await getDb();
  if (!db) throw new Error("Le service de bibliothèque est momentanément indisponible.");
  const result = await db.insert(manualDocuments).values({
    ...input,
    level: input.level || null,
    description: input.description || null,
  });
  return { id: Number(result[0].insertId) };
}
