import express, { type Express } from "express";
import path from "node:path";
import { PROPERTY_MEDIA_MAX_BYTES, getPropertyMediaKind, isPropertyMediaMimeType } from "../shared/propertyMedia";
import { storagePut } from "./storage";
import { isAdminSession } from "./adminAuth";

function safeFilename(value: string) {
  const extension = path.extname(value).toLowerCase().replace(/[^.a-z0-9]/g, "").slice(0, 10);
  const stem = path.basename(value, path.extname(value)).replace(/[^a-zA-Z0-9_-]/g, "-").replace(/-+/g, "-").slice(0, 72) || "media";
  return `${stem}${extension}`;
}

export function registerPropertyMediaUpload(app: Express) {
  const upload = async (req: express.Request, res: express.Response, adminOnly: boolean) => {
    if (adminOnly && !isAdminSession(req)) {
      res.status(401).json({ error: "Connectez-vous à l’espace ADMIN avant d’importer une image." });
      return;
    }
    const mimeType = String(req.header("x-file-type") || "").toLowerCase();
    const originalName = String(req.header("x-file-name") || "media");

    if (!isPropertyMediaMimeType(mimeType)) {
      res.status(400).json({ error: "Seuls les fichiers image et vidéo sont acceptés." });
      return;
    }
    if (!req.body || !Buffer.isBuffer(req.body) || req.body.length === 0 || req.body.length > PROPERTY_MEDIA_MAX_BYTES) {
      res.status(400).json({ error: "Le fichier est vide ou dépasse la taille maximale autorisée." });
      return;
    }

    try {
      const filename = safeFilename(originalName);
      const stored = await storagePut(`property-listings/${Date.now()}-${filename}`, req.body, mimeType);
      res.status(201).json({ url: stored.url, key: stored.key, name: filename, kind: getPropertyMediaKind(mimeType), mimeType });
    } catch (error) {
      console.error("[PropertyMediaUpload] upload failed", error);
      res.status(500).json({ error: "Le média n’a pas pu être importé. Veuillez réessayer." });
    }
  };

  app.post("/api/property-media-upload", express.raw({ type: "*/*", limit: `${PROPERTY_MEDIA_MAX_BYTES}` }), (req, res) => upload(req, res, false));
  app.post("/api/admin-media-upload", express.raw({ type: "*/*", limit: `${PROPERTY_MEDIA_MAX_BYTES}` }), (req, res) => upload(req, res, true));
}
