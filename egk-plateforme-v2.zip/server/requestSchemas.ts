import { z } from "zod";

export const requestTypeValues = [
  "general",
  "contact",
  "finance",
  "construction",
  "rental",
  "training",
  "teacher_application",
  "btp_partner",
  "reservation",
  "sanitation",
  "fad_interest",
] as const;

export const serviceRequestInputSchema = z.object({
  requestType: z.enum(requestTypeValues),
  serviceSlug: z.string().trim().min(2).max(96),
  fullName: z.string().trim().min(2, "Veuillez renseigner votre nom.").max(180),
  phone: z.string().trim().min(6, "Veuillez renseigner un numéro joignable.").max(40),
  email: z.union([z.string().trim().email(), z.literal("")]).optional(),
  location: z.string().trim().max(180).optional(),
  subject: z.string().trim().max(240).optional(),
  message: z.string().trim().min(12, "Précisez votre besoin en quelques mots.").max(4000),
  details: z.record(z.string(), z.string()).optional(),
});

export type ServiceRequestInput = z.infer<typeof serviceRequestInputSchema>;
