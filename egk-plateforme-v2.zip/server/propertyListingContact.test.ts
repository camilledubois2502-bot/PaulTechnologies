import { describe, expect, it } from "vitest";
import { canPublishPropertyListing, getPropertyOwnerContactHref, getPropertyOwnerEmailHref } from "../shared/propertyListingContact";
import { propertyAvailabilityMeta } from "../shared/propertyAvailability";

describe("contact direct des annonces immobilières", () => {
  it("prépare un lien WhatsApp contextualisé vers le propriétaire", () => {
    expect(getPropertyOwnerContactHref("07 12 34 56 78", "Maison à Divo")).toBe("https://wa.me/2250712345678?text=J'ai%20vu%20votre%20annonce%20sur%20le%20site%20E.G.K%20SARL%20et%20%C3%A7a%20m'int%C3%A9resse.%0A%0AAnnonce%20%3A%20Maison%20%C3%A0%20Divo");
  });

  it("ne produit pas de lien sans numéro exploitable", () => {
    expect(getPropertyOwnerContactHref("", "Maison à Divo")).toBeNull();
  });

  it("prépare un e-mail direct avec l’identité et le message du visiteur", () => {
    expect(getPropertyOwnerEmailHref("proprietaire@example.ci", "Maison à Divo", "Awa Koné", "Je souhaite visiter ce bien.")).toContain("mailto:proprietaire%40example.ci?subject=");
    expect(getPropertyOwnerEmailHref("proprietaire@example.ci", "Maison à Divo", "Awa Koné", "Je souhaite visiter ce bien.")).toContain("Awa%20Kon%C3%A9");
  });

  it("définit les badges disponible, loué et vendu", () => {
    expect(propertyAvailabilityMeta.available.label).toBe("Disponible");
    expect(propertyAvailabilityMeta.rented.label).toBe("Loué");
    expect(propertyAvailabilityMeta.sold.label).toBe("Vendu");
  });

  it("exige les deux consentements et les coordonnées avant publication", () => {
    expect(canPublishPropertyListing("07 12 34 56 78", "proprietaire@example.ci", true, true)).toBe(true);
    expect(canPublishPropertyListing("07 12 34 56 78", "", true, true)).toBe(false);
    expect(canPublishPropertyListing("07 12 34 56 78", "proprietaire@example.ci", true, false)).toBe(false);
  });
});
