import { createHmac, timingSafeEqual } from "node:crypto";
import type { Request } from "express";
import { getSessionCookieOptions } from "./_core/cookies";

export const ADMIN_COOKIE_NAME = "egk_admin_session";
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;

function getAdminCredentials() {
  return {
    login: process.env.EGK_ADMIN_LOGIN ?? "",
    password: process.env.EGK_ADMIN_PASSWORD ?? "",
  };
}

function safeEqual(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  if (leftBuffer.length !== rightBuffer.length) return false;
  return timingSafeEqual(leftBuffer, rightBuffer);
}

function sign(payload: string, password: string) {
  return createHmac("sha256", password).update(payload).digest("base64url");
}

export function isAdminCredential(login: string, password: string) {
  const credentials = getAdminCredentials();
  if (!credentials.login || !credentials.password) return false;
  return safeEqual(login, credentials.login) && safeEqual(password, credentials.password);
}

export function createAdminSession(login: string) {
  const { password } = getAdminCredentials();
  if (!password) throw new Error("Les identifiants de l’administration E.G.K SARL ne sont pas configurés.");
  const expiresAt = Date.now() + SESSION_TTL_MS;
  const payload = `${Buffer.from(login).toString("base64url")}.${expiresAt}`;
  return `${payload}.${sign(payload, password)}`;
}

function readCookie(req: Request, name: string) {
  const cookies = req.headers.cookie?.split(";") ?? [];
  const match = cookies.map(cookie => cookie.trim()).find(cookie => cookie.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.slice(name.length + 1)) : undefined;
}

export function isAdminSession(req: Request) {
  const { password } = getAdminCredentials();
  const token = readCookie(req, ADMIN_COOKIE_NAME);
  if (!password || !token) return false;

  const [encodedLogin, expiresAtRaw, signature] = token.split(".");
  if (!encodedLogin || !expiresAtRaw || !signature) return false;
  const expiresAt = Number(expiresAtRaw);
  if (!Number.isSafeInteger(expiresAt) || expiresAt <= Date.now()) return false;

  const payload = `${encodedLogin}.${expiresAtRaw}`;
  const expectedSignature = sign(payload, password);
  if (!safeEqual(signature, expectedSignature)) return false;

  try {
    return Buffer.from(encodedLogin, "base64url").toString("utf8") === getAdminCredentials().login;
  } catch {
    return false;
  }
}

export function getAdminCookieOptions(req: Request) {
  return {
    ...getSessionCookieOptions(req),
    maxAge: SESSION_TTL_MS,
  } as const;
}
