# Finance EGK-SARL — transcription OCR structurée

La présente référence rassemble les éléments lisibles du support transmis par E.G.K SARL. L’OCR a été exécuté panneau par panneau, sur des extraits agrandis du support d’origine. Les titres visibles et les lignes légales importantes ont été rapprochés du visuel fourni lorsque l’OCR présentait une ponctuation dégradée.

## Produit I — Extension Business

> Un financement pour développer votre petite activité et la transformer en une grande entreprise.

| Élément | Transcription confirmée |
| --- | --- |
| Montant disponible | 50 000 F à 200 000 F CFA selon votre activité et votre capacité de remboursement. |
| Remboursement | Sur 7 mois à partir d’un montant journalier perçu sur 5 jours/semaine. |
| Épargne | Ouvrez un compte d’épargne et épargnez régulièrement pour accéder à des montants plus importants. |
| Signature | Votre business aujourd’hui, votre grande entreprise demain ! |

## Produit II — Paie mon École

> Anticipez l’avenir de vos enfants en toute tranquillité.

| Élément | Transcription confirmée |
| --- | --- |
| Épargne | Épargnez pendant 9 mois sur la base de la scolarité de l’école visée. |
| Rentrée scolaire | À la rentrée, EGK-SARL prend en charge l’inscription et la scolarité de votre enfant. |
| À payer | Vous ne payez que l’inscription en ligne et les frais annexes. |

## Produit III — Vacances Libres

> Des vacances sans dettes, en toute liberté !

| Élément | Transcription confirmée |
| --- | --- |
| Épargne | Épargnez selon l’aide souhaitée pendant trois mois de vacances : juin, juillet et août. |
| Offre Soulagement | 50 000 F / mois pendant 3 mois. |
| Offre Providence | 60 000 F / mois pendant 3 mois. |
| Offre Satisfaction | 75 000 F / mois pendant 3 mois. |
| Préalable | Le préalable pour bénéficier de tous ces produits est d’avoir un compte ouvert dans notre service Micro Crédit et Solidarité. |

## Traçabilité technique

- Support source : `webdev-static-assets/egk-finance-produits.png`.
- OCR global : `webdev-static-assets/egk-finance-produits-ocr.txt`.
- OCR ciblé : extraits `finance-ocr-crops/extension-business-gray.png`, `finance-ocr-crops/paie-mon-ecole-gray.png` et `finance-ocr-crops/vacances-libres-gray.png`.
