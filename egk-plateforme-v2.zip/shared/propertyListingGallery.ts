export type PropertyListingGalleryMedia = {
  url: string;
  type: "image" | "video";
  name: string;
};

export function normalizePropertyListingGallery(value: unknown): PropertyListingGalleryMedia[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap(media => {
    if (!media || typeof media !== "object") return [];
    const candidate = media as { url?: unknown; type?: unknown; name?: unknown };
    if (typeof candidate.url !== "string" || (candidate.type !== "image" && candidate.type !== "video")) return [];
    return [{ url: candidate.url, type: candidate.type, name: typeof candidate.name === "string" ? candidate.name : "Média de l’annonce" }];
  });
}
