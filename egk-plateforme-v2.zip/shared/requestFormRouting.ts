export const requestFormTypes = [
  "general",
  "contact",
  "finance",
  "construction",
  "rental",
  "training",
  "teacher_application",
  "btp_partner",
  "reservation",
  "sanitation",
  "fad_interest",
] as const;

export type RequestFormType = (typeof requestFormTypes)[number];

function isRequestFormType(value: string | null): value is RequestFormType {
  return requestFormTypes.includes(value as RequestFormType);
}

export function getRequestFormHref(requestType: RequestFormType, serviceSlug: string = requestType) {
  const params = new URLSearchParams({ type: requestType, service: serviceSlug });
  return `/demander-un-service?${params.toString()}#formulaire-demande`;
}

export function getRequestFormContext(search: string) {
  const params = new URLSearchParams(search);
  const requestedType = params.get("type");
  const requestType: RequestFormType = isRequestFormType(requestedType) ? requestedType : "general";
  const requestedService = params.get("service")?.trim();
  const serviceSlug = requestedService && /^[a-z0-9-]{2,96}$/.test(requestedService) ? requestedService : requestType;

  return { requestType, serviceSlug };
}
