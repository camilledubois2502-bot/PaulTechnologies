export const requestSubmissionFeedback = {
  loadingLabel: "Envoi sécurisé en cours…",
  submitLabel: "Envoyer ma demande",
  successEyebrow: "Demande envoyée",
  successTitle: "Votre demande a bien été transmise.",
  successMessage: "Merci. L’équipe E.G.K SARL dispose maintenant des premières informations nécessaires pour vous recontacter.",
  successNextStep: "Prochaine étape : votre demande sera étudiée avant la prise de contact par le pôle concerné.",
  restartLabel: "Envoyer une autre demande",
} as const;
