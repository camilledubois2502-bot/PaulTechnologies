export const propertyAvailabilityValues = ["available", "rented", "sold"] as const;
export type PropertyAvailability = (typeof propertyAvailabilityValues)[number];

export const propertyAvailabilityMeta: Record<PropertyAvailability, { label: string; className: string }> = {
  available: { label: "Disponible", className: "is-available" },
  rented: { label: "Loué", className: "is-rented" },
  sold: { label: "Vendu", className: "is-sold" },
};
