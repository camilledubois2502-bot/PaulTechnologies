import type { PropertyAvailability } from "./propertyAvailability";

export type PropertyAvailabilityFilter = "all" | PropertyAvailability;

export function matchesPropertyAvailability(item: { availabilityStatus?: PropertyAvailability }, filter: PropertyAvailabilityFilter) {
  return filter === "all" || item.availabilityStatus === filter;
}
