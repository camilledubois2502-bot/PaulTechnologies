export const TRAINING_ENROLLMENT_CONTACT_HREF = "/a-propos?objet=inscription-formation#formulaire-contact";
export const TRAINING_ENROLLMENT_SUBJECT = "Demande d’inscription — GK Formation";
export const TRAINING_EDUCATION_LEVELS = [
  "Primaire",
  "Collège / 1er cycle secondaire",
  "Lycée / Terminale",
  "Baccalauréat",
  "Enseignement supérieur",
  "Autre",
] as const;

export function isTrainingEnrollmentContactSearch(search: string) {
  return new URLSearchParams(search).get("objet") === "inscription-formation";
}
