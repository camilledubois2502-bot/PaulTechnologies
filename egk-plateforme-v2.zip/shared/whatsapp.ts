const whatsappContexts = [
  ["immobilier-btp", "l’immobilier et BTP"],
  ["formation", "la formation"],
  ["agriculture", "l’agriculture"],
  ["elevage", "l’élevage"],
  ["gastronomie", "le Village gastronomique"],
  ["transport", "le transport"],
  ["salubrite", "la salubrité et l’environnement"],
  ["finance", "les solutions financières"],
] as const;

export const EGK_WHATSAPP_NUMBER = "2250564354390";

export function getWhatsAppMessage(pathname: string) {
  const context = whatsappContexts.find(([slug]) => pathname.includes(slug))?.[1] ?? "les services EGK";
  return `Bonjour EGK, je souhaite obtenir des informations concernant ${context}.`;
}

export function getWhatsAppHref(pathname: string) {
  return `https://wa.me/${EGK_WHATSAPP_NUMBER}?text=${encodeURIComponent(getWhatsAppMessage(pathname))}`;
}
