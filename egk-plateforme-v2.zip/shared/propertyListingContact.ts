export function getPropertyOwnerContactHref(phone: string, title: string) {
  const digits = phone.replace(/\D/g, "");
  if (!digits) return null;
  const whatsappNumber = digits.startsWith("225") ? digits : `225${digits}`;
  const message = `J'ai vu votre annonce sur le site E.G.K SARL et ça m'intéresse.\n\nAnnonce : ${title}`;
  return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export function getPropertyOwnerEmailHref(email: string, title: string, senderName: string, message: string) {
  const subject = `Demande concernant l’annonce « ${title} »`;
  const body = `Bonjour,\n\nJe vous contacte au sujet de l’annonce « ${title} » publiée sur E.G.K SARL.\n\nNom : ${senderName}\n\nMessage : ${message}\n\nCordialement,`;
  return `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export function canPublishPropertyListing(contactPhone: string, contactEmail: string | null, whatsappConsent: boolean, emailConsent: boolean) {
  return Boolean(contactPhone.trim() && contactEmail?.trim() && whatsappConsent && emailConsent);
}
