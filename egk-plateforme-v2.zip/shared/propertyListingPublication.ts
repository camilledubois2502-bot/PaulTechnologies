import { canPublishPropertyListing } from "./propertyListingContact";
import { normalizePropertyListingGallery } from "./propertyListingGallery";
import { PROPERTY_MEDIA_MIN_FILES } from "./propertyMedia";

export const PROPERTY_LISTING_INITIAL_STATUS = "pending" as const;

export type PropertyListingSubmissionInput = {
  fullName: string;
  location?: string;
  details?: Record<string, string>;
};

export function getPropertyListingSubmissionNotification(input: PropertyListingSubmissionInput) {
  const propertyType = input.details?.typeBien || "Bien immobilier";
  const location = input.details?.adresseBien || input.location || "localisation à confirmer";
  return {
    title: "Nouvelle annonce immobilière à valider",
    content: `${input.fullName} a soumis « ${propertyType} — ${location} ». Connectez-vous à l’administration E.G.K SARL pour l’approuver ou la refuser.`,
  } as const;
}

export function assertPropertyListingIsReady(input: { phone: string; email?: string; details?: Record<string, string> }) {
  const directContactEnabled = input.details?.contactDirectEnabled === "true";
  const emailContactEnabled = input.details?.contactEmailEnabled === "true";
  if (!canPublishPropertyListing(input.phone, input.email || null, directContactEnabled, emailContactEnabled)) {
    throw new Error("Pour soumettre l’annonce, renseignez l’e-mail et le numéro WhatsApp du propriétaire, puis confirmez les deux autorisations de contact.");
  }
  let galleryCount = 0;
  try {
    galleryCount = normalizePropertyListingGallery(JSON.parse(input.details?.mediaGallery ?? "[]")).length;
  } catch {
    galleryCount = 0;
  }
  if (galleryCount < PROPERTY_MEDIA_MIN_FILES) {
    throw new Error(`Ajoutez au moins ${PROPERTY_MEDIA_MIN_FILES} médias (photos ou vidéos) pour soumettre l’annonce.`);
  }
}

// Aliases conservés pour les anciens imports internes du projet.
export const IMMEDIATE_PROPERTY_LISTING_STATUS = PROPERTY_LISTING_INITIAL_STATUS;
export const getImmediatePropertyListingOwnerNotification = getPropertyListingSubmissionNotification;
export const assertImmediatePropertyListingIsReady = assertPropertyListingIsReady;
