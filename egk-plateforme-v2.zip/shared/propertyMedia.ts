export const PROPERTY_MEDIA_MIN_FILES = 4;
export const PROPERTY_MEDIA_MAX_FILES = 8;
export const PROPERTY_MEDIA_MAX_BYTES = 15 * 1024 * 1024;

export function isPropertyMediaMimeType(mimeType: string) {
  return mimeType.startsWith("image/") || mimeType.startsWith("video/");
}

export function getPropertyMediaKind(mimeType: string): "image" | "video" {
  return mimeType.startsWith("video/") ? "video" : "image";
}
