import { getRequestFormHref } from "./requestFormRouting";

const realEstateNeedDestinations = {
  "Location de maisons": { type: "rental", service: "location-maisons" },
  "Construction de maisons": { type: "construction", service: "construction-maison" },
  "Professionnels partenaires": { type: "btp_partner", service: "professionnels-partenaires" },
  "Modèles de maison": { type: "construction", service: "modeles-maison" },
  "Construire ma maison": { type: "construction", service: "construction-maison" },
} as const;

export function getRealEstateNeedHref(label: string) {
  const destination = realEstateNeedDestinations[label as keyof typeof realEstateNeedDestinations];
  return destination ? getRequestFormHref(destination.type, destination.service) : getRequestFormHref("construction", "immobilier-btp");
}
