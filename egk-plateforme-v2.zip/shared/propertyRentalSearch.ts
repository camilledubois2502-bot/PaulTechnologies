export type PropertyRentalCriteria = {
  region: string;
  city: string;
  housingType: string;
  maxMonthlyRent: string;
};

export type RentalSearchableProperty = {
  region?: string | null;
  city?: string | null;
  housingType?: string | null;
  monthlyRent?: number | null;
  isPublishedListing?: boolean;
  isRentalListing?: boolean;
  availabilityStatus?: "available" | "rented" | "sold";
};

function normalized(value?: string | null) {
  return String(value ?? "").trim().toLocaleLowerCase("fr-FR");
}

function includesCriterion(value: string | null | undefined, criterion: string) {
  const query = normalized(criterion);
  return !query || normalized(value).includes(query);
}

export function isRentalListingType(value?: string | null) {
  const listingType = normalized(value);
  return listingType.includes("location") || listingType.includes("louer");
}

export function isPublishedAvailableRental(item: RentalSearchableProperty) {
  return item.isPublishedListing === true && item.isRentalListing === true && item.availabilityStatus === "available";
}

export function matchesPropertyRentalCriteria(item: RentalSearchableProperty, criteria: PropertyRentalCriteria) {
  const maxMonthlyRent = Number(criteria.maxMonthlyRent);
  const matchesBudget = !criteria.maxMonthlyRent || (Number.isFinite(maxMonthlyRent) && maxMonthlyRent > 0 && typeof item.monthlyRent === "number" && item.monthlyRent <= maxMonthlyRent);
  return includesCriterion(item.region, criteria.region)
    && includesCriterion(item.city, criteria.city)
    && includesCriterion(item.housingType, criteria.housingType)
    && matchesBudget;
}
