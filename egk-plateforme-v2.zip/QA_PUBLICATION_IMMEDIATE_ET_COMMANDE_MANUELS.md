# Validation visuelle — publication immobilière et commande de manuels

Date de contrôle : 24 août 2026.

| Parcours contrôlé | Desktop — 1280 × 720 | Mobile — 375 × 812 |
|---|---|---|
| Dépôt d’annonce immobilière | L’introduction indique la publication immédiate et l’alerte administrateur. Les consentements, la galerie et le bouton « Publier mon annonce » sont visibles. | Les champs, consentements, zone médias et bouton de publication sont lisibles et restent utilisables en une colonne. |
| Manuels scolaires | Le bouton « Commander des manuels » mène au formulaire comprenant objet prérempli et zone de description. | Le bouton et le formulaire restent visibles, hiérarchisés et lisibles sur petit écran. |

Les captures confirment que les deux parcours conservent une lecture claire et une interaction accessible dans les deux formats contrôlés.
