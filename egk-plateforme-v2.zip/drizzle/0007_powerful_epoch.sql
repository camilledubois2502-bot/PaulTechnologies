CREATE TABLE `propertyOwners` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fullName` varchar(180) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `propertyOwners_id` PRIMARY KEY(`id`),
	CONSTRAINT `propertyOwners_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
ALTER TABLE `propertyListings` ADD `ownerAccountId` int;