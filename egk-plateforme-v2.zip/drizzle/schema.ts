import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const userRoleValues = [
  "user",
  "admin",
  "content_manager",
  "training_manager",
  "real_estate_manager",
  "student",
] as const;

export const requestTypeValues = [
  "general",
  "contact",
  "finance",
  "construction",
  "rental",
  "training",
  "teacher_application",
  "btp_partner",
  "reservation",
  "sanitation",
  "fad_interest",
] as const;

export const requestStatusValues = ["new", "in_review", "contacted", "closed"] as const;
export const propertyListingStatusValues = ["pending", "published", "rejected"] as const;
export const propertyAvailabilityValues = ["available", "rented", "sold"] as const;

export const catalogKindValues = [
  "property",
  "agriculture",
  "livestock",
  "transport",
  "manual",
] as const;

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", userRoleValues).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const propertyOwners = mysqlTable("propertyOwners", {
  id: int("id").autoincrement().primaryKey(),
  fullName: varchar("fullName", { length: 180 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: text("passwordHash").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const contentItems = mysqlTable("contentItems", {
  id: int("id").autoincrement().primaryKey(),
  contentType: varchar("contentType", { length: 64 }).notNull(),
  sector: varchar("sector", { length: 64 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 240 }).notNull(),
  summary: text("summary"),
  body: text("body"),
  imageUrl: text("imageUrl"),
  isPublished: boolean("isPublished").default(false).notNull(),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const catalogItems = mysqlTable("catalogItems", {
  id: int("id").autoincrement().primaryKey(),
  kind: mysqlEnum("kind", catalogKindValues).notNull(),
  sector: varchar("sector", { length: 64 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 240 }).notNull(),
  description: text("description"),
  imageUrl: text("imageUrl"),
  location: varchar("location", { length: 160 }),
  priceLabel: varchar("priceLabel", { length: 160 }),
  availabilityLabel: varchar("availabilityLabel", { length: 160 }),
  attributes: json("attributes"),
  isPublished: boolean("isPublished").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const mediaItems = mysqlTable("mediaItems", {
  id: int("id").autoincrement().primaryKey(),
  category: varchar("category", { length: 64 }).notNull(),
  title: varchar("title", { length: 240 }).notNull(),
  altText: varchar("altText", { length: 320 }),
  fileUrl: text("fileUrl").notNull(),
  mediaType: varchar("mediaType", { length: 32 }).notNull(),
  isPublished: boolean("isPublished").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const manualDocuments = mysqlTable("manualDocuments", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 240 }).notNull(),
  category: varchar("category", { length: 96 }).notNull(),
  level: varchar("level", { length: 96 }),
  description: text("description"),
  fileKey: text("fileKey").notNull(),
  isPublished: boolean("isPublished").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const serviceRequests = mysqlTable("serviceRequests", {
  id: int("id").autoincrement().primaryKey(),
  requestType: mysqlEnum("requestType", requestTypeValues).notNull(),
  serviceSlug: varchar("serviceSlug", { length: 96 }).notNull(),
  fullName: varchar("fullName", { length: 180 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  email: varchar("email", { length: 320 }),
  location: varchar("location", { length: 180 }),
  subject: varchar("subject", { length: 240 }),
  message: text("message").notNull(),
  details: json("details"),
  status: mysqlEnum("status", requestStatusValues).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const propertyListings = mysqlTable("propertyListings", {
  id: int("id").autoincrement().primaryKey(),
  submissionRequestId: int("submissionRequestId").notNull().unique(),
  ownerAccountId: int("ownerAccountId"),
  ownerName: varchar("ownerName", { length: 180 }).notNull(),
  ownerRole: varchar("ownerRole", { length: 120 }),
  title: varchar("title", { length: 240 }).notNull(),
  listingType: varchar("listingType", { length: 96 }).notNull(),
  location: varchar("location", { length: 180 }).notNull(),
  region: varchar("region", { length: 120 }),
  city: varchar("city", { length: 120 }),
  housingType: varchar("housingType", { length: 120 }),
  monthlyRent: int("monthlyRent"),
  priceLabel: varchar("priceLabel", { length: 160 }),
  configuration: varchar("configuration", { length: 180 }),
  surface: varchar("surface", { length: 120 }),
  description: text("description").notNull(),
  contactPhone: varchar("contactPhone", { length: 40 }).notNull(),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactDirectEnabled: boolean("contactDirectEnabled").default(false).notNull(),
  contactEmailEnabled: boolean("contactEmailEnabled").default(false).notNull(),
  availabilityStatus: mysqlEnum("availabilityStatus", propertyAvailabilityValues).default("available").notNull(),
  gallery: json("gallery"),
  status: mysqlEnum("status", propertyListingStatusValues).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type ServiceRequest = typeof serviceRequests.$inferSelect;
export type PropertyListing = typeof propertyListings.$inferSelect;
export type PropertyOwner = typeof propertyOwners.$inferSelect;
