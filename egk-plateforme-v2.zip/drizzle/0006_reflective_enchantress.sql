ALTER TABLE `propertyListings` ADD `region` varchar(120);--> statement-breakpoint
ALTER TABLE `propertyListings` ADD `city` varchar(120);--> statement-breakpoint
ALTER TABLE `propertyListings` ADD `housingType` varchar(120);--> statement-breakpoint
ALTER TABLE `propertyListings` ADD `monthlyRent` int;