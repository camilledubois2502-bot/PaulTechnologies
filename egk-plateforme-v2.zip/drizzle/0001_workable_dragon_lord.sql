CREATE TABLE `catalogItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kind` enum('property','agriculture','livestock','transport','manual') NOT NULL,
	`sector` varchar(64) NOT NULL,
	`slug` varchar(160) NOT NULL,
	`title` varchar(240) NOT NULL,
	`description` text,
	`imageUrl` text,
	`location` varchar(160),
	`priceLabel` varchar(160),
	`availabilityLabel` varchar(160),
	`attributes` json,
	`isPublished` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `catalogItems_id` PRIMARY KEY(`id`),
	CONSTRAINT `catalogItems_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `contentItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contentType` varchar(64) NOT NULL,
	`sector` varchar(64) NOT NULL,
	`slug` varchar(160) NOT NULL,
	`title` varchar(240) NOT NULL,
	`summary` text,
	`body` text,
	`imageUrl` text,
	`isPublished` boolean NOT NULL DEFAULT false,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contentItems_id` PRIMARY KEY(`id`),
	CONSTRAINT `contentItems_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `mediaItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`category` varchar(64) NOT NULL,
	`title` varchar(240) NOT NULL,
	`altText` varchar(320),
	`fileUrl` text NOT NULL,
	`mediaType` varchar(32) NOT NULL,
	`isPublished` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mediaItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `serviceRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requestType` enum('general','contact','finance','construction','rental','training','teacher_application','btp_partner','reservation','sanitation','fad_interest') NOT NULL,
	`serviceSlug` varchar(96) NOT NULL,
	`fullName` varchar(180) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`email` varchar(320),
	`location` varchar(180),
	`subject` varchar(240),
	`message` text NOT NULL,
	`details` json,
	`status` enum('new','in_review','contacted','closed') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `serviceRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','content_manager','training_manager','real_estate_manager','student') NOT NULL DEFAULT 'user';