CREATE TABLE `manualDocuments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(160) NOT NULL,
	`title` varchar(240) NOT NULL,
	`category` varchar(96) NOT NULL,
	`level` varchar(96),
	`description` text,
	`fileKey` text NOT NULL,
	`isPublished` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `manualDocuments_id` PRIMARY KEY(`id`),
	CONSTRAINT `manualDocuments_slug_unique` UNIQUE(`slug`)
);
