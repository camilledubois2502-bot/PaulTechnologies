# GK Formation — référence des filières

Cette transcription est issue de l’affiche **GK Formation** transmise par E.G.K SARL. Elle est conservée comme référence de contrôle pour la liste affichée sur la page Formation.

## Filières affichées dans la liste principale de l’affiche

1. Agropastoral
2. Bilingue
3. Esthétique
4. Sanitaire Social
5. Bâtiments
6. BTP
7. Communications AudioVisuelle
8. Caissier/Caissière
9. Informatiques
10. Géomètre Topographe

## Vérification OCR

L’extraction OCR de l’affiche confirme les dix intitulés ci-dessus dans la liste principale située à droite du visuel. Les termes sont reproduits tels qu’ils apparaissent sur l’affiche, y compris les majuscules, pluriels et la graphie de « Communications AudioVisuelle ».

> Référence technique : `webdev-static-assets/gk-formation-filieres-ocr.txt`.
