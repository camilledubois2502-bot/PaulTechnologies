# Produits Finance — référence transcrite

Cette référence reprend les produits affichés sur le support **EGK-SARL — Service Micro Crédit et Solidarité** transmis par E.G.K SARL.

## Produits

| Produit | Modalités principales affichées |
| --- | --- |
| Extension Business | « Un financement pour développer votre petite activité et la transformer en une grande entreprise. » Montant disponible : **50 000 F à 200 000 F CFA** selon votre activité et votre capacité de remboursement ; remboursement sur 7 mois à partir d’un montant journalier perçu sur 5 jours/semaine ; compte d’épargne régulier indiqué. |
| Paie mon École | « Anticipez l’avenir de vos enfants en toute tranquillité. » Épargne pendant **9 mois** sur la base de la scolarité de l’école visée ; à la rentrée, EGK-SARL prend en charge l’inscription et la scolarité de votre enfant ; seuls l’inscription en ligne et les frais annexes restent à payer. |
| Vacances Libres | « Des vacances sans dettes, en toute liberté ! » Épargne selon l’aide souhaitée pendant trois mois de vacances (**juin, juillet, août**) ; Offre Soulagement : **50 000 F/mois** pendant 3 mois ; Offre Providence : **60 000 F/mois** pendant 3 mois ; Offre Satisfaction : **75 000 F/mois** pendant 3 mois ; compte ouvert au service Micro Crédit et Solidarité indiqué comme préalable. |

> Les montants, conditions d’éligibilité, disponibilités et engagements sont affichés à titre informatif sur le site et doivent être confirmés par E.G.K SARL avant toute souscription.

> Référence détaillée : `FINANCE_PRODUCTS_OCR_TRANSCRIPT.md`.
