# Validation visuelle — recherche locative

Date de contrôle : 24 août 2026.

| Parcours contrôlé | Desktop — 1280 × 720 | Mobile — 375 × 812 |
|---|---|---|
| Catalogue immobilier | Les filtres de recherche par région, ville, type de logement et budget sont lisibles en grille, séparés des filtres existants de parcours et de statut. | Les filtres sont disposés en une colonne ; les libellés, champs et annonces restent lisibles. |
| Demande locative | Le bloc de téléchargement PDF, les champs d’identité, profession, secteur d’activité, localisation recherchée, type de logement et budget sont visibles et lisibles. | Le bloc PDF et tous les champs requis restent accessibles et lisibles sans chevauchement sur petit écran. |

Les deux parcours conservent une hiérarchie claire et une interaction utilisable dans les formats contrôlés.

La recherche par critères est limitée aux annonces de location publiées, disponibles et documentées avec un loyer mensuel. Les modèles et fiches à compléter restent consultables dans le catalogue général, mais ne sont pas retournés par une recherche de location.
