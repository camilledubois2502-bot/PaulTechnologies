# Passage en production — EGK

## Objet de cette version

La plateforme met en place une vitrine institutionnelle responsive, des parcours sectoriels, des catalogues de fiches, des formulaires enregistrés de façon sécurisée, une interface d’administration par rôles et les fondations de l’espace étudiant. Les contenus visibles qui sont explicitement indiqués comme « à publier », « indicatifs » ou « à confirmer » doivent être remplacés par des données validées avant toute communication publique.

## Éléments prioritaires à transmettre à l’équipe de gestion

| Élément | Attendu | Usage dans la plateforme |
|---|---|---|
| Identité graphique | Logo vectoriel, charte, variantes claires/sombres, favicon | En-tête, pied de page, partages et identité de marque |
| Coordonnées officielles | Numéro WhatsApp, téléphone, email, adresse, horaires, liens sociaux | Contact, bouton WhatsApp et pied de page |
| Médias validés | Photos de l’équipe, projets, sites, formations, bâtiments, activités et événements | Hero, Galerie, Actualités, fiches et pages sectorielles |
| Informations financières | Conditions, critères, pièces attendues et mentions juridiques approuvées | Rubrique Finance et formulaires associés |
| Catalogue immobilier | Annonces réelles, plans, superficies, prix, statut, médias et conditions | Immobilier, location et Projet FAD |
| Produits et lignes | Productions réellement disponibles, tarifs, conditionnements, itinéraires et horaires officiels | Catalogues Agriculture, Élevage et Transport |
| Formation | Filières, calendrier, conditions, tarifs, cours, enseignants et règles d’accès étudiant | Institut, inscriptions et espace étudiant |
| Documents pédagogiques | Manuels autorisés, métadonnées, catégories et règles de consultation | Bibliothèque numérique protégée |

## Actions de paramétrage recommandées

L’administrateur principal doit se connecter à l’interface d’administration, puis attribuer les rôles nécessaires : `content_manager`, `training_manager`, `real_estate_manager` ou `student`. Les gestionnaires peuvent ensuite créer des contenus, fiches catalogue et références médias depuis l’administration. Les médias doivent être téléversés dans le stockage sécurisé du projet ; l’URL retournée au format `/manus-storage/...` peut être renseignée dans les champs de contenu et de catalogue.

Le numéro WhatsApp officiel doit être ajouté à la fonction de contact contextualisé avant publication afin que le bouton flottant envoie les visiteurs directement vers l’équipe EGK. Tant qu’aucun numéro n’est communiqué, le bouton ouvre une conversation préremplie dans l’application WhatsApp de l’utilisateur.

## Contrôles avant publication

Vérifier que les coordonnées, mentions légales, conditions de service, tarifs, disponibilités et médias correspondent aux informations officiellement approuvées par EGK. Les flux d’inscription, de financement et de Projet FAD doivent être examinés avec les responsables métier et, lorsque nécessaire, par un conseil juridique ou financier compétent avant leur activation publique.

Le fichier `robots.txt` et le `sitemap.xml` visent le domaine `entreprise-gethemekoffi.com`. Si l’adresse finale est différente, remplacer cette origine dans ces deux fichiers et configurer les outils de suivi correspondants. Les métadonnées éditoriales de chaque page devront être enrichies lors de la publication de contenus réels.
